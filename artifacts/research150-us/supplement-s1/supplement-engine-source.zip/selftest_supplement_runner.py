"""Synthetic S1 integration and manifest-binding tests. No historical labels."""
from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import pandas as pd

import run_supplement
from research_engine import file_sha256,write_json
from selftest_engine import synthetic


class SupplementRunnerChecks(unittest.TestCase):
    def test_full216_registry_synthetic_runner_and_joint180_family(self):
        with tempfile.TemporaryDirectory(prefix='S1_SYNTHETIC_ONLY_') as directory:
            root=Path(directory);(root/'bulk').mkdir()
            for document in (*run_supplement.DOCUMENTS,'engine-code-hashes.json'):
                shutil.copyfile(run_supplement.ROOT/document,root/document)
            shutil.copyfile(run_supplement.ROOT/'bulk/dataset-plan.json',root/'bulk/dataset-plan.json')
            plan_hash=file_sha256(root/'bulk/dataset-plan.json')
            dates=['2026-01-02','2026-01-29'];rows=[]
            for symbol in run_supplement.UNIVERSE:
                for day in dates:
                    path=root/'bulk'/f'{symbol}_{day}.csv.gz'
                    synthetic(ticker=symbol,session=day).to_csv(path,index=False,compression='gzip')
                    rows.append({'ticker':symbol,'session':day,'status':'complete','plan_sha256':plan_hash,
                                 'canonical_path':str(path),'canonical_sha256':file_sha256(path),
                                 'source':{'kind':'SYNTHETIC_ONLY','received_at':'2026-11-12T00:00:00Z',
                                           'file_sha256':'synthetic-file','packet_hash':'synthetic-packet'}})
            manifest=root/'bulk/synthetic-manifest.json'
            write_json(manifest,{'statistics':{'plan_sha256':plan_hash},'sessions':rows})
            prior=root/'SYNTHETIC_V2_REFERENCE';prior.mkdir()
            old_registry=json.loads((root/'pilot-registry-v2.json').read_text())
            old_ids=[trial['trial_id'] for trial in old_registry['trials']]
            pd.DataFrame(0.,index=dates,columns=old_ids).to_parquet(prior/'daily_proxy_returns_cost05.parquet')
            old_results=[{'canonical_trial_id':name,'roundtrip_cost_bps':5,
                          'overall':{'additive_constant_notional_return':0.}} for name in old_ids]
            write_json(prior/'per-trial-results.json',old_results)
            shutil.copyfile(manifest,prior/'input-coverage-manifest.json')
            write_json(prior/'run-seal.json',{'phase':'development','source_dataset_plan_sha256':plan_hash,
                                            'code':json.loads((root/'engine-code-hashes.json').read_text())['code'],
                                            'inputs':{'input-coverage-manifest.json':file_sha256(prior/'input-coverage-manifest.json')}})
            write_json(prior/'report.json',{'evaluated_policy_count':108,
                                           'code_and_data_seal_sha256':file_sha256(prior/'run-seal.json'),
                                           'artifacts':{'per-trial-results.json':file_sha256(prior/'per-trial-results.json')}})
            output=root/'SYNTHETIC_S1_RESULTS'
            with patch.object(run_supplement,'ROOT',root),contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(ValueError,'v2_reference_runs_required'):
                    run_supplement.metadata_seal(root/'INVALID_NO_V2',manifest,'development',[])
                with self.assertRaisesRegex(ValueError,'v2_phase_mismatch'):
                    run_supplement.metadata_seal(root/'INVALID_CROSS_PHASE',manifest,'chronological_evaluation',[prior])
                altered={'statistics':{'plan_sha256':plan_hash},'sessions':[{**rows[0],'canonical_sha256':'different-version'},*rows[1:]]}
                write_json(root/'altered-input-version.json',altered)
                with self.assertRaisesRegex(ValueError,'v2_supplement_canonical_input_version_mismatch'):
                    run_supplement.metadata_seal(root/'INVALID_VERSION',root/'altered-input-version.json','development',[prior])
                old_report=(prior/'report.json').read_bytes()
                write_json(prior/'report.json',{**json.loads(old_report),'code_and_data_seal_sha256':'wrong'})
                with self.assertRaisesRegex(ValueError,'v2_report_run_seal_binding_mismatch'):
                    run_supplement.metadata_seal(root/'INVALID_REPORT_BINDING',manifest,'development',[prior])
                (prior/'report.json').write_bytes(old_report)
                run_supplement.metadata_seal(output,manifest,'development',[prior])
                sealed=json.loads((output/'run-seal.json').read_text())
                self.assertFalse(sealed['supplement_price_labels_opened'])
                self.assertTrue(sealed['v2_development_outcomes_previously_observed_by_runner_author'])
                run_supplement.run(output)
                with self.assertRaisesRegex(ValueError,'outcomes_already_written'):
                    run_supplement.run(output)
            report=json.loads((output/'report.json').read_text())
            self.assertEqual(report['evaluated_policy_count'],216)
            self.assertEqual(report['evaluated_policy_cost_views'],648)
            self.assertEqual(report['combined_primary_contrasts'],180)
            self.assertEqual(report['falsification_only_candidates'],9)
            self.assertEqual(report['original_150_hypotheses_tested'],0)
            registry=json.loads((root/'supplement-registry-s1.json').read_text())
            results=json.loads((output/'per-policy-results.json').read_text())
            self.assertEqual(len(results),648)
            self.assertEqual({row['canonical_policy_id'] for row in results},
                             {row['policy_id'] for row in registry['policy_entries']})
            comparisons=json.loads((output/'paired-contrasts.json').read_text())
            self.assertEqual(len(comparisons),126*3*2)
            self.assertEqual({row['contrast_id'] for row in comparisons},
                             {row['contrast_id'] for row in registry['contrasts']})
            combined=pd.read_parquet(output/'combined180_daily_contrasts_cost05.parquet')
            self.assertEqual(combined.shape,(2,180))
            self.assertTrue(combined[old_ids[0].removesuffix('_candidate')].eq(0).all())
            inference=json.loads((output/'joint-combined180-inference.json').read_text())
            self.assertEqual(inference['development']['5']['contrasts'],180)
            self.assertEqual(inference['development']['5']['status'],'INSUFFICIENT_EVIDENCE')
            calendar=[r for r in results if r['family']=='H079_US_S1' and r['role']=='candidate']
            self.assertTrue(all(r['distinct_active_event_days']<=1 for r in calendar))
            example=pd.read_parquet(output/'trades'/'H139_US_S1_W15_H1_LONG_B_always_momentum.parquet')
            self.assertGreater(len(example),0)
            self.assertTrue((example.signal_at-example.feature_start).eq(pd.Timedelta(minutes=255)).all())
            self.assertTrue((example.entry_at-example.signal_at).eq(pd.Timedelta(minutes=1)).all())
            self.assertTrue(example.source_kind.eq('SYNTHETIC_ONLY').all())


if __name__=='__main__':
    unittest.main(verbosity=2)
