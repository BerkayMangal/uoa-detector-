"""Frozen S1 feature definitions only; no labels, fitting, network, or economics.

Inputs must come from the unchanged v2 validated complete-minute loader and
aggregator. The frozen proposal is hash checked before calendar metadata use.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from numpy.lib.stride_tricks import sliding_window_view

ROOT = Path(__file__).resolve().parent.parent
PROPOSAL_SHA256 = '8bd54e97616e24dbc6ea3a259860d56f1181523910e762d347218d55490cd754'
FAMILIES = ('H079_US_S1', 'H080_US_S1', 'H139_US_S1', 'H140_US_S1', 'H144_US_S1')
BASELINES = {
    'H079_US_S1': ('momentum_no_calendar',),
    'H080_US_S1': ('always_same_side',),
    'H139_US_S1': ('always_momentum', 'always_contrarian'),
    'H140_US_S1': ('always_momentum', 'always_contrarian'),
    'H144_US_S1': ('always_same_side',),
}


def frozen_proposal() -> dict:
    raw = (ROOT / 'supplement-proposal.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != PROPOSAL_SHA256:
        raise ValueError('supplement_proposal_hash_mismatch')
    return json.loads(raw)


def _rs_hurst_prior16(returns: np.ndarray) -> np.ndarray:
    """Vectorized three-scale R/S slope on exactly sixteen PRIOR returns."""
    result = np.full(len(returns), np.nan)
    if len(returns) < 17:
        return result
    windows = sliding_window_view(returns, 16)[:-1]
    valid = np.isfinite(windows).all(axis=1)
    logs = []
    for scale in (4, 8, 16):
        blocks = windows.reshape(len(windows), 16 // scale, scale)
        sd = blocks.std(axis=2, ddof=1)
        cumulative = np.cumsum(blocks - blocks.mean(axis=2, keepdims=True), axis=2)
        # Include Z[0]=0 exactly as specified, independent of floating residuals.
        ranges = np.maximum(cumulative.max(axis=2), 0) - np.minimum(cumulative.min(axis=2), 0)
        block_valid = np.isfinite(sd) & np.isfinite(ranges) & (sd > 0) & (ranges > 0)
        valid &= block_valid.all(axis=1)
        ratio = np.divide(ranges, sd, out=np.full_like(ranges, np.nan), where=block_valid)
        q = ratio.mean(axis=1)  # No nanmean: one invalid block invalidates the scale.
        valid &= np.isfinite(q) & (q > 0)
        with np.errstate(divide='ignore', invalid='ignore'):
            logs.append(np.log(q))
    x = np.log(np.array([4., 8., 16.]))
    centered_x = x - x.mean()
    y = np.column_stack(logs)
    slope = ((y-y.mean(axis=1, keepdims=True))*centered_x).sum(axis=1) / np.dot(centered_x, centered_x)
    slope[~valid] = np.nan
    result[16:] = slope
    return result


def _autocorrelation_prior9(returns: np.ndarray) -> np.ndarray:
    """Eight overlapping lag pairs from nine prior returns, excluding current."""
    result = np.full(len(returns), np.nan)
    if len(returns) < 10:
        return result
    prior = sliding_window_view(returns, 9)[:-1]
    left, right = prior[:, :-1], prior[:, 1:]
    left_centered = left-left.mean(axis=1, keepdims=True)
    right_centered = right-right.mean(axis=1, keepdims=True)
    denominator = np.sqrt(np.square(left_centered).sum(axis=1)*np.square(right_centered).sum(axis=1))
    valid = np.isfinite(prior).all(axis=1) & np.isfinite(denominator) & (denominator > 0)
    result[9:] = np.divide((left_centered*right_centered).sum(axis=1), denominator,
                           out=np.full(len(prior), np.nan), where=valid)
    return result


def _native_prior60_tail(minutes: pd.DataFrame) -> pd.Series:
    """Index by current-minute start; prior window excludes that minute."""
    starts = pd.DatetimeIndex(pd.to_datetime(minutes.start_time, utc=True))
    if starts.has_duplicates or not starts.is_monotonic_increasing:
        raise ValueError('tail_native_times_not_unique_ordered')
    if len(starts) > 1 and not ((starts[1:]-starts[:-1]) == pd.Timedelta(minutes=1)).all():
        raise ValueError('tail_native_minute_gap')
    values = np.log(minutes.close.to_numpy(dtype=float)/minutes.open.to_numpy(dtype=float))
    result = np.full(len(values), np.nan)
    if len(values) > 60:
        windows = sliding_window_view(values, 60)[:-1]
        ordered = np.sort(windows, axis=1)
        lower, upper = ordered[:, :3].mean(axis=1), ordered[:, -3:].mean(axis=1)
        valid = np.isfinite(windows).all(axis=1) & (upper > lower)
        result[60:] = np.divide(upper+lower, upper-lower, out=np.full(len(windows), np.nan), where=valid)
    return pd.Series(result, index=starts)


def build_features(bars: pd.DataFrame, minutes: pd.DataFrame) -> pd.DataFrame:
    """Construct all five families on a single registered width, without labels."""
    if bars.empty:
        raise ValueError('no_signal_bars')
    widths = bars.timeframe_minutes.unique()
    if len(widths) != 1 or widths[0] not in (1, 5, 15):
        raise ValueError('single_registered_width_required')
    width = int(widths[0])
    frame = bars.sort_values(['ticker', 'session', 'bar_index']).reset_index(drop=True).copy()
    frame['session'] = frame.session.astype(str)
    for col in ('start_time', 'end_time'):
        frame[col] = pd.to_datetime(frame[col], utc=True)
    frame['r'] = np.log(frame.close/frame.open)
    grouped = frame.groupby(['ticker', 'session'], sort=False)
    frame['warmup9'] = grouped.cumcount() >= 9
    frame['warmup16'] = grouped.cumcount() >= 16
    frame['momentum3'] = np.log(frame.close/grouped.close.shift(3))
    frame['feature_start9'] = grouped.start_time.shift(9)
    frame['feature_start16'] = grouped.start_time.shift(16)
    tail_start = frame.start_time-pd.Timedelta(minutes=60)
    frame['feature_start_tail'] = frame.feature_start9.where(frame.feature_start9 <= tail_start, tail_start)
    for column in ('hurst_rs16', 'autocorr_prior9', 'tail_balance60'):
        frame[column] = np.nan

    calendars = frozen_proposal()['calendar_flags_full_month']
    unknown = sorted(set(frame.session.str[:7])-set(calendars))
    if unknown:
        raise ValueError('calendar_month_not_registered:' + ','.join(unknown))
    month_start_days = {d for v in calendars.values() for d in v['first_two']}
    month_end_days = {d for v in calendars.values() for d in v['last_two']}
    frame['month_start2'] = frame.session.isin(month_start_days)
    frame['month_end2'] = frame.session.isin(month_end_days)

    minute_groups = {(str(ticker), str(session)): group.sort_values('start_time')
                     for (ticker, session), group in minutes.groupby(['ticker', 'session'], sort=False)}
    for key, indices in grouped.indices.items():
        group = frame.loc[indices]
        if not np.array_equal(group.bar_index.to_numpy(), np.arange(len(group))):
            raise ValueError('signal_bar_index_gap')
        if not ((group.end_time-group.start_time) == pd.Timedelta(minutes=width)).all():
            raise ValueError('signal_bar_duration_mismatch')
        if len(group) > 1 and not (group.start_time.diff().iloc[1:] == pd.Timedelta(minutes=width)).all():
            raise ValueError('signal_bar_time_gap')
        returns = group.r.to_numpy(dtype=float)
        frame.loc[indices, 'hurst_rs16'] = _rs_hurst_prior16(returns)
        frame.loc[indices, 'autocorr_prior9'] = _autocorrelation_prior9(returns)
        raw = minute_groups.get((str(key[0]), str(key[1])))
        if raw is None:
            raise ValueError('missing_native_minutes_for_tail')
        tails = _native_prior60_tail(raw)
        frame.loc[indices, 'tail_balance60'] = tails.reindex(pd.DatetimeIndex(group.start_time)).to_numpy()
    return frame


def eligibility_mask(features: pd.DataFrame, family: str) -> pd.Series:
    if family not in FAMILIES:
        raise ValueError('unregistered_family')
    eligible = features.warmup9 & np.isfinite(features.r)
    if family == 'H079_US_S1':
        eligible &= np.isfinite(features.momentum3)
    elif family == 'H139_US_S1':
        eligible &= features.warmup16 & np.isfinite(features.hurst_rs16)
    elif family == 'H140_US_S1':
        eligible &= np.isfinite(features.autocorr_prior9)
    elif family == 'H144_US_S1':
        eligible &= np.isfinite(features.tail_balance60)
    return eligible.astype(bool)


def information_rows(features: pd.DataFrame, family: str) -> pd.DataFrame:
    column = 'feature_start16' if family == 'H139_US_S1' else 'feature_start_tail' if family == 'H144_US_S1' else 'feature_start9'
    result = features.loc[eligibility_mask(features, family), ['ticker', 'session', 'end_time', column]].copy()
    return result.rename(columns={column: 'feature_start'})


def signal_rows(features: pd.DataFrame, family: str, side: str, role: str,
                baseline_id: str | None = None) -> pd.DataFrame:
    if family not in FAMILIES or side not in ('long', 'short') or role not in ('candidate', 'falsification_diagnostic', 'baseline'):
        raise ValueError('unregistered_signal_specification')
    if role == 'falsification_diagnostic' and (family != 'H080_US_S1' or side != 'short'):
        raise ValueError('unregistered_falsification_arm')
    if role == 'baseline' and baseline_id not in BASELINES[family]:
        raise ValueError('unregistered_or_missing_baseline')
    if role != 'baseline' and baseline_id is not None:
        raise ValueError('candidate_cannot_select_baseline')
    sign = 1 if side == 'long' else -1
    eligible = eligibility_mask(features, family)
    momentum = (sign*features.momentum3 > 0) & (sign*features.r > 0)
    if role == 'baseline':
        if baseline_id == 'momentum_no_calendar':
            predicate = momentum
        elif baseline_id == 'always_momentum':
            predicate = sign*features.r > 0
        elif baseline_id == 'always_contrarian':
            predicate = sign*features.r < 0
        else:
            predicate = pd.Series(True, index=features.index)
    elif family == 'H079_US_S1':
        predicate = features.month_end2 & momentum
    elif family == 'H080_US_S1':
        predicate = features.month_start2
    elif family == 'H139_US_S1':
        predicate = ((features.hurst_rs16 > .55) & (sign*features.r > 0)) | ((features.hurst_rs16 < .45) & (sign*features.r < 0))
    elif family == 'H140_US_S1':
        predicate = np.sign(features.autocorr_prior9)*np.sign(features.r) == sign
    else:
        predicate = sign*features.tail_balance60 > 0
    column = 'feature_start16' if family == 'H139_US_S1' else 'feature_start_tail' if family == 'H144_US_S1' else 'feature_start9'
    result = features.loc[eligible & predicate, ['ticker', 'session', 'end_time', column]].copy()
    result = result.rename(columns={column:'feature_start'})
    result['direction'] = sign
    return result[['ticker', 'session', 'end_time', 'direction', 'feature_start']]
