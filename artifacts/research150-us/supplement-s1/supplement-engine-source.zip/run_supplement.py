"""Separate S1 runner. Frozen v2 economics are imported, never modified.

Runner author observed v2 development results before writing this code. The
S1 formula author reports remaining blind to those outcomes. This is an
exploratory extension, not a globally outcome-untouched confirmation.
"""
from __future__ import annotations

import argparse
from collections import Counter,defaultdict
from datetime import datetime,timezone
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import sys

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
ENGINE=Path(__file__).resolve().parent
V2_ENGINE=ROOT/'engine'
sys.path.insert(0,str(V2_ENGINE))
from research_engine import (aggregate_complete_bars,daily_portfolio,file_sha256,
                             load_canonical,net_events,priced_events,write_json)
from inference import purge_overlapping_intervals,simultaneous_lower_bounds
from run_pilot import period_summary
from frozen_supplement_features import build_features,eligibility_mask,signal_rows

UNIVERSE=('SPY','QQQ','AAPL','NFLX','NVDA','TSLA','MSFT','META','AMZN')
DOCUMENTS=('supplement-proposal.json','supplement-proposal.md','supplement-registry-s1.json',
           'supplement-freeze-s1.json','pilot-protocol-v2.md','pilot-registry-v2.json',
           'pilot-v2-implementation-clarification.md','pilot-v2-inference-gates.md','pilot-freeze-v2.json')
CODE=('run_supplement.py','selftest_supplement_runner.py','frozen_supplement_features.py','selftest_supplement_features.py')


def registry_checked()->dict:
    registry=json.loads((ROOT/'supplement-registry-s1.json').read_text())
    policies=registry['policy_entries'];contrasts=registry['contrasts']
    ids={p['policy_id'] for p in policies}
    roles=Counter(p['role'] for p in policies)
    if len(ids)!=216 or len(policies)!=216 or len(contrasts)!=126 or roles!={'candidate':81,'falsification_diagnostic':9,'baseline':126}:
        raise ValueError('supplement_registry_count_mismatch')
    if any(c['candidate_id'] not in ids or c['baseline_id'] not in ids for c in contrasts):
        raise ValueError('unbound_registered_contrast')
    return registry


def metadata_seal(output:Path,manifest:Path,phase:str,v2_runs:list[Path])->None:
    output.mkdir(parents=True,exist_ok=True)
    if (output/'run-seal.json').exists():raise ValueError('seal_already_exists')
    registry_checked()
    proposal=json.loads((ROOT/'supplement-proposal.json').read_text())
    if tuple(proposal['shared_framework']['universe'])!=UNIVERSE:raise ValueError('universe_mismatch')
    for filename in ('supplement-freeze-s1.json','pilot-freeze-v2.json'):
        frozen=json.loads((ROOT/filename).read_text())
        for name,checksum in frozen['files'].items():
            if file_sha256(ROOT/Path(name).name)!=checksum:raise ValueError('frozen_document_hash_mismatch')
    plan_bytes=(ROOT/'bulk/dataset-plan.json').read_bytes();plan=json.loads(plan_bytes)
    plan_sha=hashlib.sha256(plan_bytes).hexdigest();coverage=json.loads(manifest.read_text())
    if plan_sha!=proposal['references']['dataset_plan_sha256']:raise ValueError('frozen_supplement_dataset_plan_mismatch')
    if tuple(plan['universe'])!=UNIVERSE:raise ValueError('plan_universe_mismatch')
    if (coverage.get('statistics',{}).get('plan_sha256')!=plan_sha or
            any(row.get('plan_sha256')!=plan_sha for row in coverage['sessions'])):
        raise ValueError('coverage_dataset_plan_hash_mismatch')
    frozen_code=json.loads((ROOT/'engine-code-hashes.json').read_text())['code']
    for name,checksum in frozen_code.items():
        if file_sha256(V2_ENGINE/name)!=checksum:raise ValueError('immutable_v2_code_changed')
    write_json(output/'input-coverage-manifest.json',coverage)
    write_json(output/'input-dataset-plan.json',plan)
    sources=[];input_files=['input-coverage-manifest.json','input-dataset-plan.json'];reference_hashes={}
    current_hashes={(r['ticker'],r['session']):r['canonical_sha256'] for r in coverage['sessions'] if r['status']=='complete' and r['ticker'] in UNIVERSE}
    if not v2_runs:raise ValueError('v2_reference_runs_required_for_joint_multiplicity')
    for index,path in enumerate(v2_runs):
        v2_seal=json.loads((path/'run-seal.json').read_text())
        v2_report=json.loads((path/'report.json').read_text())
        if phase!='all' and v2_seal['phase']!=phase:raise ValueError('v2_phase_mismatch_no_cross_phase_outcome_access')
        if v2_report.get('code_and_data_seal_sha256')!=file_sha256(path/'run-seal.json'):
            raise ValueError('v2_report_run_seal_binding_mismatch')
        if v2_seal.get('code')!=frozen_code or v2_seal.get('source_dataset_plan_sha256')!=plan_sha:
            raise ValueError('v2_code_or_plan_binding_mismatch')
        if file_sha256(path/'input-coverage-manifest.json')!=v2_seal['inputs']['input-coverage-manifest.json']:
            raise ValueError('v2_input_manifest_binding_mismatch')
        v2_coverage=json.loads((path/'input-coverage-manifest.json').read_text())
        for row in v2_coverage['sessions']:
            if row['status']!='complete':continue
            day=row['session']
            if ((v2_seal['phase']=='development' and day>='2026-10-01') or
                    (v2_seal['phase']=='chronological_evaluation' and day<'2026-10-01')):continue
            key=(row['ticker'],day);checksum=row['canonical_sha256']
            if key in current_hashes and current_hashes[key]!=checksum:
                raise ValueError('v2_supplement_canonical_input_version_mismatch')
            if key in reference_hashes and reference_hashes[key]!=checksum:
                raise ValueError('conflicting_v2_reference_input_versions')
            reference_hashes[key]=checksum
        if v2_report['evaluated_policy_count']!=108:raise ValueError('incomplete_v2_reference_registry')
        if file_sha256(path/'per-trial-results.json')!=v2_report['artifacts']['per-trial-results.json']:
            raise ValueError('v2_reference_results_hash_mismatch')
        files={}
        for original in ('run-seal.json','report.json','input-coverage-manifest.json','per-trial-results.json','daily_proxy_returns_cost05.parquet'):
            target=f'v2_{index}_{original}';shutil.copyfile(path/original,output/target)
            files[original]=target;input_files.append(target)
        sources.append({'original_directory':str(path),'phase':v2_seal['phase'],'files':files,
                        'matrix_hash_basis':'captured_at_S1_seal_not_claimed_as_original_v2_completion_hash'})
    by_date=defaultdict(set)
    for symbol,day in current_hashes:
        if phase=='all' or (phase=='development' and day<'2026-10-01') or (phase=='chronological_evaluation' and day>='2026-10-01'):
            by_date[day].add(symbol)
    for day,symbols in by_date.items():
        if symbols==set(UNIVERSE) and any((symbol,day) not in reference_hashes for symbol in UNIVERSE):
            raise ValueError('missing_v2_reference_input_for_common_date')
    seal={'created_at':datetime.now(timezone.utc).isoformat(),'phase':phase,'universe':list(UNIVERSE),
          'supplement_price_labels_opened':False,'v2_development_outcomes_previously_observed_by_runner_author':True,
          'interpretation':'Exploratory code written after v2 development outcomes; S1 definitions separately frozen before their own run.',
          'source_dataset_plan_sha256':plan_sha,'source_manifest_sha256':file_sha256(manifest),
          'documents':{name:file_sha256(ROOT/name) for name in DOCUMENTS},
          'code':{name:file_sha256(ENGINE/name) for name in CODE},'immutable_v2_code':frozen_code,
          'inputs':{name:file_sha256(output/name) for name in input_files},'v2_reference_sources':sources,
          'runtime':{'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'pyarrow':version('pyarrow')}}
    write_json(output/'run-seal.json',seal)
    print(json.dumps({'status':'SEALED_NO_SUPPLEMENT_LABELS_OPENED','seal_sha256':file_sha256(output/'run-seal.json'),'path':str(output)}),flush=True)


def v2_contrasts(output:Path,seal:dict,common:list[str])->pd.DataFrame:
    registry=json.loads((ROOT/'pilot-registry-v2.json').read_text());pieces=[]
    for source in seal['v2_reference_sources']:
        files=source['files'];frame=pd.read_parquet(output/files['daily_proxy_returns_cost05.parquet'])
        frame.index=frame.index.astype(str)
        results=json.loads((output/files['per-trial-results.json']).read_text())
        for row in results:
            if row['roundtrip_cost_bps']!=5:continue
            if abs(float(frame[row['canonical_trial_id']].sum())-row['overall']['additive_constant_notional_return'])>1e-9:
                raise ValueError('v2_daily_matrix_summary_mismatch')
        values={}
        for trial in registry['trials']:
            if trial['arm']=='candidate':
                values[trial['trial_id'].removesuffix('_candidate')]=frame[trial['trial_id']]-frame[trial['baseline_id']]
        pieces.append(pd.DataFrame(values))
    combined=pd.concat(pieces)
    if combined.index.duplicated().any():raise ValueError('duplicate_v2_reference_date')
    if not set(common)<=set(combined.index):raise ValueError('missing_v2_paired_date')
    result=combined.reindex(common)
    if result.shape[1]!=54 or not np.isfinite(result.to_numpy()).all():raise ValueError('invalid_v2_contrast_matrix')
    return result


def run(output:Path)->None:
    seal=json.loads((output/'run-seal.json').read_text())
    for group,base in [('documents',ROOT),('code',ENGINE),('immutable_v2_code',V2_ENGINE),('inputs',output)]:
        for name,checksum in seal[group].items():
            if file_sha256(base/name)!=checksum:raise ValueError('run_seal_hash_mismatch:'+group+':'+name)
    if (output/'report.json').exists():raise ValueError('outcomes_already_written')
    registry=registry_checked();proposal=json.loads((ROOT/'supplement-proposal.json').read_text())
    plan=json.loads((output/'input-dataset-plan.json').read_text());manifest=json.loads((output/'input-coverage-manifest.json').read_text())
    official=[row['session'] for row in plan['sessions']]
    expected=[day for day in official if seal['phase']=='all' or
              (seal['phase']=='development' and day<'2026-10-01') or
              (seal['phase']=='chronological_evaluation' and day>='2026-10-01')]
    certified=[row for row in manifest['sessions'] if row['status']=='complete' and row['session'] in expected and row['ticker'] in UNIVERSE]
    symbols=defaultdict(set)
    for row in certified:symbols[row['session']].add(row['ticker'])
    common=sorted(day for day,items in symbols.items() if items==set(UNIVERSE));chosen=[row for row in certified if row['session'] in common]
    coverage={'expected_sessions':len(expected),'complete_nine_symbol_sessions':len(common),
              'certified_ticker_sessions':len(certified),'common_dates':common,'excluded_sessions':sorted(set(expected)-set(common)),
              'ticker_session_status_counts':dict(Counter(row['status'] for row in manifest['sessions'] if row['session'] in expected)),
              'selection':'Retrospective whole-session volume/price quality filter, using later minutes; not live-known eligibility.',
              'availability':'Historical event-time proxy; physical receipts remain separate and are not backdated.',
              'physical_receipts':[{k:row[k] for k in ('ticker','session','source','canonical_sha256') if k in row} for row in chosen]}
    write_json(output/'analysis-coverage.json',coverage)
    if not common:
        write_json(output/'report.json',{'status':'BLOCKED_DATA','coverage':coverage,'evaluated_policy_count':0,'supplement_price_labels_opened':False});return
    prior=v2_contrasts(output,seal,common)
    minutes=load_canonical([Path(row['canonical_path']) for row in chosen],expected_hashes={row['canonical_path']:row['canonical_sha256'] for row in chosen})
    features={width:build_features(aggregate_complete_bars(minutes,width),minutes) for width in (1,5,15)}
    feature_coverage=[]
    for width,frame in features.items():
        frame.to_parquet(output/f'features_{width}m.parquet',index=False)
        for family in sorted({policy['family'] for policy in registry['policy_entries']}):
            grouped=frame.assign(eligible=eligibility_mask(frame,family)).groupby(['ticker','session']).eligible.agg(['count','sum']).reset_index()
            grouped['family']=family;grouped['bar_minutes']=width;grouped=grouped.rename(columns={'count':'complete_bars','sum':'family_valid_bars'})
            feature_coverage.append(grouped)
    pd.concat(feature_coverage,ignore_index=True).to_parquet(output/'feature-eligibility-coverage.parquet',index=False)
    provenance=pd.DataFrame([{'ticker':r['ticker'],'session':r['session'],'source_kind':r.get('source',{}).get('kind'),
                             'source_received_at':r.get('source',{}).get('received_at'),'source_raw_sha256':r.get('source',{}).get('raw_body_sha256'),
                             'source_file_sha256':r.get('source',{}).get('file_sha256'),'source_packet_hash':r.get('source',{}).get('packet_hash'),
                             'canonical_file_sha256':r['canonical_sha256']} for r in chosen])
    (output/'trades').mkdir(exist_ok=True)
    results=[];monthly=[];intervals=[];evaluated=[];matrices={cost:{} for cost in (5,10,20)}
    for number,policy in enumerate(registry['policy_entries']):
        path_id=policy['policy_id'];width=policy['width_minutes'];horizon=policy['hold_minutes'];frame=features[width]
        signals=signal_rows(frame,policy['family'],policy['side'],policy['role'],policy.get('baseline_definition_id'))
        events=priced_events(minutes,signals,horizon)
        events=events.merge(signals[['ticker','session','end_time','feature_start']],how='left',
                            left_on=['ticker','session','signal_at'],right_on=['ticker','session','end_time'],validate='one_to_one')
        if events.feature_start.isna().any() or (events.feature_start>events.signal_at).any():raise ValueError('invalid_information_history')
        events['label_end']=events.exit_at;events=events.merge(provenance,on=['ticker','session'],how='left',validate='many_to_one')
        events['availability_basis']='historical_event_time_proxy_not_contemporaneous_receipt'
        selected=events[events.selected].copy();selected.to_parquet(output/'trades'/f'{path_id}.parquet',index=False)
        intervals.append(selected[['session','feature_start','label_end']])
        for cost in (5,10,20):
            net=net_events(events,cost);view=f'{path_id}_cost{cost:02d}';matrices[cost][path_id]=daily_portfolio(net,tuple(common))
            result={**policy,'canonical_policy_id':path_id,'policy_cost_view_id':view,'roundtrip_cost_bps':cost,
                    'signals':len(signals),'unpriceable_signal_windows':int((~events.eligible_quote_window).sum()),
                    'overlap_suppressed_signals':int((events.eligible_quote_window&~events.selected).sum()),
                    'distinct_active_event_days':int(net.session.nunique()),'overall':period_summary(net,common,expected)}
            for label,condition in [('development',lambda day:day<'2026-10-01'),('chronological_evaluation',lambda day:day>='2026-10-01')]:
                result[label]=period_summary(net,[day for day in common if condition(day)],[day for day in expected if condition(day)])
            results.append(result);evaluated.append({**policy,'policy_cost_view_id':view,'roundtrip_cost_bps':cost,'evaluated':True})
            for month in sorted({day[:7] for day in expected}):
                monthly.append({'canonical_policy_id':path_id,'policy_cost_view_id':view,'month':month,
                                **period_summary(net,[d for d in common if d.startswith(month)],[d for d in expected if d.startswith(month)])})
        if (number+1)%18==0:print(json.dumps({'status':'RUNNING','policies_done':number+1,'policies_total':216}),flush=True)
    daily={cost:pd.DataFrame(values).reindex(common) for cost,values in matrices.items()}
    contrast_frames={};contrasts=[]
    result_lookup={(row['canonical_policy_id'],row['roundtrip_cost_bps']):row for row in results}
    for cost,frame in daily.items():
        frame.index.name='session';frame.to_parquet(output/f'daily_proxy_returns_cost{cost:02d}.parquet')
        values={}
        for comparison in registry['contrasts']:
            values[comparison['contrast_id']]=frame[comparison['candidate_id']]-frame[comparison['baseline_id']]
            for label,condition in [('development',lambda day:day<'2026-10-01'),('chronological_evaluation',lambda day:day>='2026-10-01')]:
                dates=[d for d in common if condition(d)];series=values[comparison['contrast_id']].reindex(dates)
                cand=result_lookup[(comparison['candidate_id'],cost)][label];base=result_lookup[(comparison['baseline_id'],cost)][label]
                net_difference=float(series.sum()) if dates else None
                saving=cost*(base['trades']-cand['trades'])/90000 if dates else None
                contrasts.append({**comparison,'roundtrip_cost_bps':cost,'period':label,'complete_paired_sessions':len(dates),
                                  'mean_daily_difference':float(series.mean()) if dates else None,'additive_net_difference':net_difference,
                                  'relative_cost_saving_from_trade_count':saving,
                                  'additive_gross_difference':net_difference-saving if dates else None,
                                  'interpretation':'Reduced turnover/cost is not itself predictive alpha; both registered baselines retained.'})
        contrast_frames[cost]=pd.DataFrame(values).reindex(common)
        contrast_frames[cost].to_parquet(output/f'supplement_daily_contrasts_cost{cost:02d}.parquet')
    combined=pd.concat([prior,contrast_frames[5]],axis=1)
    if combined.shape[1]!=180 or combined.columns.duplicated().any():raise ValueError('global_multiplicity_family_mismatch')
    combined.to_parquet(output/'combined180_daily_contrasts_cost05.parquet')
    inference={}
    for label,condition in [('development',lambda day:day<'2026-10-01'),('chronological_evaluation',lambda day:day>='2026-10-01')]:
        data=combined.loc[[d for d in common if condition(d)]]
        inference[label]={str(block):simultaneous_lower_bounds(data,official,block=block) for block in (5,10)}
    all_intervals=pd.concat(intervals,ignore_index=True).drop_duplicates();folds=[]
    for month in range(4,10):
        first=f'2026-{month:02d}-01';following=f'2026-{month+1:02d}-01'
        training=all_intervals[all_intervals.session<first];evaluation=all_intervals[(all_intervals.session>=first)&(all_intervals.session<following)]
        purged=purge_overlapping_intervals(training,evaluation);expected_train=[d for d in official if d<first];expected_eval=[d for d in official if first<=d<following]
        observed_train=[d for d in common if d<first];observed_eval=[d for d in common if first<=d<following]
        complete=set(expected_train)<=set(observed_train) and set(expected_eval)<=set(observed_eval)
        folds.append({'evaluation_month':first[:7],'training_expected_sessions':len(expected_train),'training_complete_sessions':len(observed_train),
                      'evaluation_expected_sessions':len(expected_eval),'evaluation_complete_sessions':len(observed_eval),
                      'training_intervals_before_purge':len(training),'training_intervals_after_purge':len(purged),'purged_intervals':len(training)-len(purged),
                      'fitted_parameters':0,'status':'FIXED_RULE_REFERENCE_FOLD' if complete else 'BLOCKED_DATA'})
    artifacts={'per-policy-results.json':results,'per-month-results.json':monthly,'evaluated-registry.json':evaluated,
               'paired-contrasts.json':contrasts,'joint-combined180-inference.json':inference,'purged-folds.json':folds}
    for name,value in artifacts.items():write_json(output/name,value)
    report={'status':'DESCRIPTIVE_ONLY','phase':seal['phase'],'coverage':coverage,'registry_counts':registry['counts'],
            'evaluated_policy_count':216,'evaluated_policy_cost_views':648,'combined_primary_contrasts':180,
            'source_directed_candidates':81,'falsification_only_candidates':9,'original_150_hypotheses_tested':0,
            'new_us_price_adaptations_this_supplement':5,'supplement_price_labels_opened':True,
            'code_and_data_seal_sha256':file_sha256(output/'run-seal.json'),
            'interpretation':'Exploratory implementation written after v2 development outcomes; no untouched confirmation or automatic promotion.',
            'chronological_evaluation_label':proposal['shared_framework']['final_period_label'],
            'dsr':'INSUFFICIENT_EVIDENCE','option_results':'NOT_TESTED','news_predictive_filters':'NOT_TESTED',
            'limitations':['Retrospective common-valid-day conditioning; native quality exclusions may be nonrandom.',
                           'Stock open-price proxies with assumed roundtrip costs; short borrow unverified; not option PnL.',
                           'Calendar filters change exposure/costs; repeated trades and idle dates are not independent calendar-event replications.',
                           'H80 short is falsification only and cannot support the source positive-drift claim.',
                           'Combined180 correction does not erase5184 earlier exploratory configurations or unknown prior search history.'],
            'artifacts':{name:file_sha256(output/name) for name in artifacts}}
    write_json(output/'report.json',report)
    print(json.dumps({'status':'DESCRIPTIVE_ONLY','policies':216,'cost_views':648,'common_sessions':len(common),'output':str(output)}),flush=True)


def main()->None:
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--manifest',type=Path,default=ROOT/'bulk/development-coverage-manifest.json')
    parser.add_argument('--phase',choices=['development','chronological_evaluation','all'],default='development')
    parser.add_argument('--v2-run',action='append',type=Path,default=[])
    group=parser.add_mutually_exclusive_group(required=True);group.add_argument('--seal-only',action='store_true');group.add_argument('--run',action='store_true')
    args=parser.parse_args()
    if args.seal_only:metadata_seal(args.output,args.manifest,args.phase,args.v2_run)
    else:run(args.output)


if __name__=='__main__':main()
