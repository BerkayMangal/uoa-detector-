"""Synthetic-only S1 feature, causality, calendar, and registration checks."""
from pathlib import Path
import hashlib
import json
import sys
import unittest

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT/'engine'))
from research_engine import aggregate_complete_bars, validate_minutes
from frozen_supplement_features import (
    BASELINES, FAMILIES, _native_prior60_tail, _rs_hurst_prior16, build_features, eligibility_mask,
    frozen_proposal, information_rows, signal_rows,
)


def synthetic(session='2026-01-02', ticker='SPY'):
    starts=pd.date_range(pd.Timestamp(session+' 09:30',tz='America/New_York').tz_convert('UTC'),periods=390,freq='min')
    n=np.arange(390,dtype=float)
    opens=100+0.01*n
    returns=.0003*np.sin(n*.73)+.0001*np.cos(n*.17)+.00002
    closes=opens*np.exp(returns)
    return pd.DataFrame({'ticker':ticker,'session':session,'start_time':starts,'end_time':starts+pd.Timedelta(minutes=1),
                         'open':opens,'close':closes,'high':np.maximum(opens,closes)+.01,'low':np.minimum(opens,closes)-.01,'volume':100+n%7})


def make(raw=None,width=1):
    minutes=validate_minutes(synthetic() if raw is None else raw)
    return build_features(aggregate_complete_bars(minutes,width),minutes)


def manual_hurst(x):
    # Deliberately scalar reference, independent of vectorized implementation.
    ys=[]
    for scale in [4,8,16]:
        ratios=[]
        for first in range(0,16,scale):
            block=x[first:first+scale]
            mu=sum(block)/scale
            sd=(sum((v-mu)**2 for v in block)/(scale-1))**.5
            cumulative=[0.]
            for value in block:cumulative.append(cumulative[-1]+value-mu)
            ratios.append((max(cumulative)-min(cumulative))/sd)
        ys.append(np.log(sum(ratios)/len(ratios)))
    xs=np.log([4.,8.,16.])
    return sum((x-xs.mean())*(y-np.mean(ys)) for x,y in zip(xs,ys))/sum((x-xs.mean())**2 for x in xs)


class SupplementFeatureChecks(unittest.TestCase):
    def test_freeze_hashes_and_trial_counts(self):
        freeze=json.loads((ROOT/'supplement-freeze-s1.json').read_text())
        for name,expected in freeze['files'].items():
            self.assertEqual(hashlib.sha256(Path(name).read_bytes()).hexdigest(),expected)
        registry=json.loads((ROOT/'supplement-registry-s1.json').read_text())
        paths=registry['policy_entries'];contrasts=registry['contrasts']
        self.assertEqual(len(paths),216)
        self.assertEqual(len({p['policy_id'] for p in paths}),216)
        self.assertEqual(sum(p['role']=='baseline' for p in paths),126)
        self.assertEqual(sum(p['role']=='falsification_diagnostic' for p in paths),9)
        self.assertEqual(len(contrasts),126)
        known={p['policy_id'] for p in paths}
        self.assertTrue(all(c['candidate_id'] in known and c['baseline_id'] in known for c in contrasts))
        self.assertEqual(frozen_proposal()['executable_original_ids'],[79,80,139,140,144])

    def test_calendar_flags_use_full_month_not_capture_subset(self):
        for session,start,end in [('2026-11-11',False,False),('2026-11-30',False,True),('2026-06-24',False,False),('2026-01-02',True,False),('2026-01-05',True,False),('2026-01-06',False,False),('2026-01-29',False,True)]:
            frame=make(synthetic(session=session),15)
            self.assertTrue(frame.month_start2.eq(start).all(),session)
            self.assertTrue(frame.month_end2.eq(end).all(),session)
        with self.assertRaisesRegex(ValueError,'calendar_month_not_registered'):
            make(synthetic(session='2027-01-04'))

    def test_hurst_scalar_reference_and_every_block_validity(self):
        frame=make();k=30
        expected=manual_hurst(frame.r.iloc[k-16:k].to_numpy())
        self.assertAlmostEqual(frame.iloc[k].hurst_rs16,expected,places=12)
        values=np.array([0.,0.,0.,0.,1.,2.,3.,4.,5.,6.,8.,10.,11.,14.,13.,12.,9.])
        self.assertTrue(np.isnan(_rs_hurst_prior16(values)[16]))
        self.assertTrue(np.isnan(_rs_hurst_prior16(np.zeros(30))).all())

    def test_exact_autocorrelation_prior_pairs(self):
        frame=make();k=25
        expected=np.corrcoef(frame.r.iloc[k-9:k-1],frame.r.iloc[k-8:k])[0,1]
        self.assertAlmostEqual(frame.iloc[k].autocorr_prior9,expected,places=12)
        self.assertTrue(frame.autocorr_prior9.iloc[:9].isna().all())

    def test_native_tail_exact_top_bottom_three_and_unbounded_value(self):
        raw=synthetic();n=np.arange(len(raw))+1
        raw['close']=raw.open*np.exp(n*.00001)
        raw['high']=raw[['open','close']].max(axis=1)+.01
        raw['low']=raw[['open','close']].min(axis=1)-.01
        minutes=validate_minutes(raw)
        frame=build_features(aggregate_complete_bars(minutes,5),minutes)
        k=15;start=k*5
        returns=np.log(minutes.close.iloc[start-60:start]/minutes.open.iloc[start-60:start]).sort_values().to_numpy()
        lower,upper=returns[:3].mean(),returns[-3:].mean()
        expected=(upper+lower)/(upper-lower)
        self.assertGreater(expected,1)
        self.assertAlmostEqual(frame.iloc[k].tail_balance60,expected,places=12)

    def test_current_signal_bar_excluded_from_prior_features(self):
        raw=synthetic();before=make(raw,5);k=20
        changed=raw.copy();i=k*5
        changed.loc[i:i+4,'close']*=1.1
        changed.loc[i:i+4,'high']=changed.loc[i:i+4,['open','close']].max(axis=1)+.01
        after=make(changed,5)
        for field in ['hurst_rs16','autocorr_prior9','tail_balance60']:
            self.assertEqual(before.iloc[k][field],after.iloc[k][field],field)
        self.assertNotEqual(before.iloc[k].r,after.iloc[k].r)

    def test_future_mutation_cannot_change_prior_features_or_signals(self):
        raw=synthetic();before=make(raw)
        changed=raw.copy();changed.loc[120:,['open','high','low','close']]*=5
        after=make(changed)
        pd.testing.assert_frame_equal(before.iloc[:120],after.iloc[:120])
        for family in FAMILIES:
            for side in ['long','short']:
                pd.testing.assert_frame_equal(signal_rows(before.iloc[:120],family,side,'candidate'),signal_rows(after.iloc[:120],family,side,'candidate'))

    def test_session_reset_and_exact_first_eligible_clocks(self):
        raw=pd.concat([synthetic(),synthetic(session='2026-01-05')],ignore_index=True)
        expected_h={1:'09:47',5:'10:55',15:'13:45'}
        expected_t={1:'10:31',5:'10:35',15:'12:00'}
        for width in [1,5,15]:
            frame=make(raw,width)
            for session in ['2026-01-02','2026-01-05']:
                group=frame[frame.session==session]
                self.assertTrue(group.hurst_rs16.iloc[:16].isna().all())
                for family,expected in [('H139_US_S1',expected_h[width]),('H144_US_S1',expected_t[width])]:
                    first=information_rows(group,family).iloc[0]
                    self.assertEqual(first.end_time.tz_convert('America/New_York').strftime('%H:%M'),expected)
                    self.assertEqual(first.feature_start.tz_convert('America/New_York').strftime('%H:%M'),'09:30')

    def test_zero_variance_blocks_all_arms_and_threshold_equality_means_cash(self):
        raw=synthetic();raw['close']=raw.open
        frame=make(raw)
        for family in ['H139_US_S1','H140_US_S1','H144_US_S1']:
            self.assertFalse(eligibility_mask(frame,family).any())
            for baseline in BASELINES[family]:
                self.assertEqual(len(signal_rows(frame,family,'long','baseline',baseline)),0)
        one=make().iloc[[40]].copy();one['r']=.01
        for h in [.45,.55]:
            one['hurst_rs16']=h
            self.assertEqual(len(signal_rows(one,'H139_US_S1','long','candidate')),0)
            self.assertEqual(len(signal_rows(one,'H139_US_S1','short','candidate')),0)
        one['autocorr_prior9']=0.
        self.assertTrue(eligibility_mask(one,'H140_US_S1').all())
        self.assertEqual(len(signal_rows(one,'H140_US_S1','long','candidate')),0)
        self.assertEqual(len(signal_rows(one,'H140_US_S1','long','baseline','always_momentum')),1)

    def test_two_baselines_and_side_roles_are_explicit(self):
        one=make().iloc[[80]].copy();one['r']=.01;one['hurst_rs16']=.7;one['autocorr_prior9']=.3
        for family in ['H139_US_S1','H140_US_S1']:
            self.assertEqual(len(signal_rows(one,family,'long','baseline','always_momentum')),1)
            self.assertEqual(len(signal_rows(one,family,'long','baseline','always_contrarian')),0)
            with self.assertRaisesRegex(ValueError,'missing_baseline'):
                signal_rows(one,family,'long','baseline')
        self.assertEqual(len(signal_rows(one,'H080_US_S1','short','falsification_diagnostic')),1)
        with self.assertRaisesRegex(ValueError,'unregistered_falsification'):
            signal_rows(one,'H079_US_S1','short','falsification_diagnostic')

    def test_missing_native_minute_rejected_without_forward_fill(self):
        minutes=validate_minutes(synthetic())
        bars=aggregate_complete_bars(minutes,5)
        with self.assertRaisesRegex(ValueError,'tail_native_minute_gap'):
            build_features(bars,minutes.drop(index=45))

    def test_native_tail_accepts_explicit_microsecond_and_nanosecond_units(self):
        raw=synthetic()
        results=[]
        for unit in ['us','ns']:
            converted=raw.copy()
            for field in ['start_time','end_time']:
                converted[field]=converted[field].dt.as_unit(unit)
            self.assertEqual(converted.start_time.dtype.unit,unit)
            tail=_native_prior60_tail(converted)
            self.assertTrue(tail.iloc[:60].isna().all())
            self.assertTrue(np.isfinite(tail.iloc[60:]).all())
            results.append(tail.to_numpy())
        np.testing.assert_allclose(results[0],results[1],rtol=0,atol=0,equal_nan=True)


if __name__=='__main__':
    unittest.main(verbosity=2)
