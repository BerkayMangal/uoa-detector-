"""Causal, complete-bar stock reference research. No option economics are inferred.

This work-only module contains evaluation machinery, not fitted parameters.
Family formulas come from the separately frozen registry before any real run.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class Economics:
    entry_delay_full_minutes: int = 1
    horizons_minutes: tuple[int, ...] = (1, 5, 15)
    roundtrip_cost_bps: tuple[int, ...] = (5, 10, 20)
    universe_size: int = 9
    forbid_overlap: bool = True


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_minutes(frame: pd.DataFrame) -> pd.DataFrame:
    """Reject malformed or incomplete ticker-days; never fill missing prices."""
    required = {'ticker', 'session', 'start_time', 'end_time', 'open', 'high', 'low', 'close', 'volume'}
    if not required.issubset(frame.columns):
        raise ValueError('missing_canonical_columns')
    data = frame.copy()
    for column in ('start_time', 'end_time'):
        data[column] = pd.to_datetime(data[column], utc=True, errors='raise')
    for column in ('open', 'high', 'low', 'close', 'volume'):
        data[column] = pd.to_numeric(data[column], errors='raise')
    if not np.isfinite(data[['open', 'high', 'low', 'close', 'volume']].to_numpy(dtype=float)).all():
        raise ValueError('nonfinite_ohlcv')
    if (data[['open', 'high', 'low', 'close']] <= 0).any().any() or (data.volume < 0).any():
        raise ValueError('nonpositive_price_or_negative_volume')
    if ((data.high < data[['open', 'close', 'low']].max(axis=1)) |
            (data.low > data[['open', 'close', 'high']].min(axis=1))).any():
        raise ValueError('inconsistent_ohlc')
    if ((data.end_time - data.start_time) != pd.Timedelta(minutes=1)).any():
        raise ValueError('not_one_complete_minute')
    data['session'] = data.session.astype(str)
    data = data.sort_values(['ticker', 'session', 'start_time']).reset_index(drop=True)
    if data.duplicated(['ticker', 'start_time']).any():
        raise ValueError('duplicate_minute')
    local = data.start_time.dt.tz_convert('America/New_York')
    if not (local.dt.strftime('%Y-%m-%d') == data.session).all():
        raise ValueError('session_date_mismatch')
    for (_, _), group in data.groupby(['ticker', 'session'], sort=False):
        if len(group) not in (210, 390):
            raise ValueError('incomplete_session_row_count')
        times = group.start_time
        if not (times.diff().iloc[1:] == pd.Timedelta(minutes=1)).all():
            raise ValueError('missing_minute')
        first = times.iloc[0].tz_convert('America/New_York')
        last = group.end_time.iloc[-1].tz_convert('America/New_York')
        if (first.hour, first.minute) != (9, 30) or (last.hour, last.minute) not in ((13, 0), (16, 0)):
            raise ValueError('invalid_rth_bounds')
    data['minute_index'] = data.groupby(['ticker', 'session'], sort=False).cumcount()
    return data


def load_canonical(paths: Iterable[Path], *, expected_hashes: dict[str, str] | None = None) -> pd.DataFrame:
    pieces = []
    for path in paths:
        if expected_hashes is not None and file_sha256(path) != expected_hashes[str(path)]:
            raise ValueError('canonical_file_hash_mismatch')
        pieces.append(pd.read_csv(path, dtype={'ticker': str, 'session': str}))
    if not pieces:
        raise ValueError('no_complete_canonical_sessions')
    return validate_minutes(pd.concat(pieces, ignore_index=True))


def aggregate_complete_bars(minutes: pd.DataFrame, timeframe: int) -> pd.DataFrame:
    """Bars are anchored at09:30 ET and contain exactly1/5/15 completed minutes."""
    if timeframe not in (1, 5, 15):
        raise ValueError('unregistered_timeframe')
    frame = minutes.copy()
    frame['bar_index'] = frame.minute_index // timeframe
    grouped = frame.groupby(['ticker', 'session', 'bar_index'], sort=False)
    bars = grouped.agg(start_time=('start_time', 'first'), end_time=('end_time', 'last'),
                       open=('open', 'first'), high=('high', 'max'), low=('low', 'min'),
                       close=('close', 'last'), volume=('volume', 'sum'),
                       minute_count=('start_time', 'size')).reset_index()
    if not (bars.minute_count == timeframe).all():
        raise ValueError('incomplete_aggregated_bar')
    bars['timeframe_minutes'] = timeframe
    return bars


def within_session_rolling(bars: pd.DataFrame, column: str, window: int, method: str,
                           *, lag: int = 0) -> pd.Series:
    def calculate(series: pd.Series) -> pd.Series:
        roll = series.shift(lag).rolling(window, min_periods=window)
        return getattr(roll, method)()
    return bars.groupby(['ticker', 'session'], sort=False)[column].transform(calculate)


def prior_session_features(bars: pd.DataFrame, calendar_sessions: tuple[str, ...]) -> pd.DataFrame:
    """Previous-day fields require the immediately previous official session."""
    daily = bars.groupby(['ticker', 'session'], sort=False).agg(
        previous_close=('close', 'last'), previous_high=('high', 'max'),
        previous_low=('low', 'min'), previous_volume=('volume', 'sum')).reset_index()
    predecessor = {current: prior for prior, current in zip(calendar_sessions, calendar_sessions[1:])}
    result = bars.copy()
    result['previous_session'] = result.session.map(predecessor)
    daily = daily.rename(columns={'session': 'previous_session'})
    return result.merge(daily, how='left', on=['ticker', 'previous_session'], validate='many_to_one')


def standard_features(bars: pd.DataFrame, calendar_sessions: tuple[str, ...]) -> pd.DataFrame:
    """Point-in-time feature vocabulary. Trial registry decides exact use."""
    frame = bars.sort_values(['ticker', 'session', 'bar_index']).reset_index(drop=True).copy()
    day_keys = ['ticker', 'session']
    grouped = frame.groupby(day_keys, sort=False)
    frame['session_open'] = grouped.open.transform('first')
    frame['session_return'] = frame.close / frame.session_open - 1
    frame['bar_return'] = frame.close / frame.open - 1
    frame['return_1'] = grouped.close.pct_change(fill_method=None)
    frame['return_3'] = grouped.close.pct_change(periods=3, fill_method=None)
    frame['range'] = frame.high - frame.low
    frame['body'] = frame.close - frame.open
    frame['upper_wick'] = frame.high - frame[['open', 'close']].max(axis=1)
    frame['lower_wick'] = frame[['open', 'close']].min(axis=1) - frame.low
    frame['close_location'] = (frame.close - frame.low).div(frame['range'].replace(0, np.nan))
    typical = (frame.high + frame.low + frame.close) / 3
    frame['price_volume'] = typical * frame.volume
    frame['cum_volume'] = frame.groupby(day_keys, sort=False).volume.cumsum()
    frame['vwap'] = frame.groupby(day_keys, sort=False).price_volume.cumsum().div(
        frame.cum_volume.replace(0, np.nan))
    frame['vwap_distance'] = frame.close / frame.vwap - 1
    previous_close = grouped.close.shift(1)
    frame['true_range'] = pd.concat([frame['range'], (frame.high-previous_close).abs(),
                                     (frame.low-previous_close).abs()], axis=1).max(axis=1)
    for window in (5, 10, 14, 20, 50):
        frame[f'sma_{window}'] = within_session_rolling(frame, 'close', window, 'mean')
        frame[f'previous_high_{window}'] = within_session_rolling(frame, 'high', window, 'max', lag=1)
        frame[f'previous_low_{window}'] = within_session_rolling(frame, 'low', window, 'min', lag=1)
        frame[f'volume_mean_{window}'] = within_session_rolling(frame, 'volume', window, 'mean', lag=1)
    frame['atr_14'] = within_session_rolling(frame, 'true_range', 14, 'mean')
    frame['std_20'] = within_session_rolling(frame, 'close', 20, 'std')
    frame['bb_z_20'] = (frame.close-frame.sma_20).div(frame.std_20.replace(0, np.nan))
    frame['volume_ratio_20'] = frame.volume.div(frame.volume_mean_20.replace(0, np.nan))
    delta = grouped.close.diff()
    frame['gain'] = delta.clip(lower=0)
    frame['loss'] = -delta.clip(upper=0)
    gains = within_session_rolling(frame, 'gain', 14, 'mean')
    losses = within_session_rolling(frame, 'loss', 14, 'mean')
    ratio = gains.div(losses.replace(0, np.nan))
    frame['rsi_14'] = 100 - 100/(1+ratio)
    frame.loc[(losses == 0) & (gains > 0), 'rsi_14'] = 100
    frame.loc[(losses == 0) & (gains == 0), 'rsi_14'] = 50
    frame = prior_session_features(frame, calendar_sessions)
    frame['opening_gap'] = frame.session_open / frame.previous_close - 1
    # Opening15-minute range exists only after all constituent minutes closed.
    first15 = frame[frame.bar_index < (15 // frame.timeframe_minutes)].groupby(day_keys).agg(
        opening15_high=('high', 'max'), opening15_low=('low', 'min'))
    frame = frame.join(first15, on=day_keys)
    mask = (frame.bar_index + 1) * frame.timeframe_minutes < 15
    frame.loc[mask, ['opening15_high', 'opening15_low']] = np.nan
    # Benchmark information must be from the exact same completed bar timestamp.
    spy = frame[frame.ticker == 'SPY'][['session', 'end_time', 'session_return', 'return_3']].rename(
        columns={'session_return': 'spy_session_return', 'return_3': 'spy_return_3'})
    frame = frame.merge(spy, how='left', on=['session', 'end_time'], validate='many_to_one')
    frame['relative_session_return'] = frame.session_return - frame.spy_session_return
    frame['relative_return_3'] = frame.return_3 - frame.spy_return_3
    return frame.drop(columns=['price_volume', 'gain', 'loss'])


def priced_events(minutes: pd.DataFrame, signals: pd.DataFrame, horizon: int,
                  economics: Economics = Economics()) -> pd.DataFrame:
    """Signals require ticker/session/end_time/direction; no future price is a feature."""
    if horizon not in economics.horizons_minutes:
        raise ValueError('unregistered_horizon')
    required = {'ticker', 'session', 'end_time', 'direction'}
    if not required.issubset(signals):
        raise ValueError('signal_schema_missing')
    selected = signals[['ticker', 'session', 'end_time', 'direction']].copy()
    selected['signal_at'] = pd.to_datetime(selected.pop('end_time'), utc=True)
    if not selected.direction.isin([-1, 1]).all():
        raise ValueError('direction_must_be_signed_one')
    if selected.duplicated(['ticker', 'session', 'signal_at']).any():
        raise ValueError('ambiguous_simultaneous_signal')
    selected['entry_at'] = selected.signal_at + pd.Timedelta(minutes=economics.entry_delay_full_minutes)
    selected['exit_at'] = selected.entry_at + pd.Timedelta(minutes=horizon)
    prices = minutes[['ticker', 'session', 'start_time', 'open']]
    selected = selected.merge(prices.rename(columns={'start_time': 'entry_at', 'open': 'entry_price'}),
                              how='left', on=['ticker', 'session', 'entry_at'], validate='many_to_one')
    selected = selected.merge(prices.rename(columns={'start_time': 'exit_at', 'open': 'exit_price'}),
                              how='left', on=['ticker', 'session', 'exit_at'], validate='many_to_one')
    selected['eligible_quote_window'] = selected.entry_price.notna() & selected.exit_price.notna()
    selected = selected.sort_values(['ticker', 'session', 'entry_at']).reset_index(drop=True)
    chosen = np.zeros(len(selected), dtype=bool)
    entry_ns = selected.entry_at.astype('int64').to_numpy()
    exit_ns = selected.exit_at.astype('int64').to_numpy()
    eligible = selected.eligible_quote_window.to_numpy()
    for indices in selected.groupby(['ticker', 'session'], sort=False).indices.values():
        blocked_until = -1
        for index in indices[eligible[indices]]:
            if economics.forbid_overlap and entry_ns[index] < blocked_until:
                continue
            chosen[index] = True
            blocked_until = exit_ns[index]
    selected['selected'] = chosen
    selected['gross_return'] = selected.direction * (selected.exit_price / selected.entry_price - 1)
    selected.loc[~selected.selected, 'gross_return'] = np.nan
    return selected


def net_events(events: pd.DataFrame, roundtrip_cost_bps: int,
               economics: Economics = Economics()) -> pd.DataFrame:
    if roundtrip_cost_bps not in economics.roundtrip_cost_bps:
        raise ValueError('unregistered_cost')
    result = events[events.selected].copy()
    result['roundtrip_cost_bps'] = roundtrip_cost_bps
    result['net_return'] = result.gross_return - roundtrip_cost_bps / 10000
    return result


def daily_portfolio(events: pd.DataFrame, complete_sessions: tuple[str, ...],
                    economics: Economics = Economics()) -> pd.Series:
    """Equal fixed notional ticker sleeves, idle cash0; no incomplete day treated as cash."""
    daily = events.groupby('session').net_return.sum().div(economics.universe_size)
    return daily.reindex(complete_sessions, fill_value=0).astype(float)


def summary(events: pd.DataFrame, complete_sessions: tuple[str, ...],
            economics: Economics = Economics()) -> dict[str, Any]:
    daily = daily_portfolio(events, complete_sessions, economics)
    if len(daily) == 0:
        return {'status': 'NO_COMPLETE_SESSIONS', 'sessions': 0, 'trades': 0}
    equity = (1+daily).cumprod()
    peak = pd.concat([pd.Series([1.0]), equity.reset_index(drop=True)], ignore_index=True).cummax().iloc[1:]
    drawdown = equity.to_numpy() / peak.to_numpy() - 1
    gains = events.loc[events.net_return > 0, 'net_return'].sum()
    losses = -events.loc[events.net_return < 0, 'net_return'].sum()
    return {
        'status': 'EVALUATED', 'sessions': int(len(daily)), 'trades': int(len(events)),
        'active_sessions': int((events.groupby('session').size() > 0).sum()),
        'long_trades': int((events.direction == 1).sum()), 'short_trades': int((events.direction == -1).sum()),
        'net_trade_mean_bps': float(events.net_return.mean()*10000) if len(events) else None,
        'gross_trade_mean_bps': float(events.gross_return.mean()*10000) if len(events) else None,
        'win_rate': float((events.net_return > 0).mean()) if len(events) else None,
        'profit_factor': float(gains/losses) if losses > 0 else None,
        'profit_factor_reason': None if losses > 0 else 'no_negative_returns_or_no_trades',
        'daily_rebalanced_proxy_index_return': float(equity.iloc[-1]-1),
        'additive_constant_notional_return': float(daily.sum()),
        'reference_notional_usd': 10000,
        'additive_reference_pnl_usd': float(daily.sum()*10000),
        'worst_daily_proxy_return': float(daily.min()),
        'mean_entry_delay_minutes': 1 if len(events) else None,
        'roundtrip_reference_turnover_units': float(2*len(events)/economics.universe_size),
        'mean_daily_portfolio_return': float(daily.mean()),
        'max_daily_equity_drawdown': float(drawdown.min()),
        'daily_return_std': float(daily.std(ddof=1)) if len(daily) > 1 else None,
        'dsr': None, 'dsr_reason': 'not_established_for_dependent_registry_and_partially_preobserved_evaluation_split',
        'uncertainty': None, 'uncertainty_reason': 'see_joint_block_inference_artifact',
        'economic_basis': 'stock_ohlcv_reference_open_prices; not_executable_quote_or_option_pnl',
        'short_borrow_cost': 'unverified_and_not_included',
    }


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
