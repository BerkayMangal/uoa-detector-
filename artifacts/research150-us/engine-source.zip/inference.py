"""Preregistered paired session-vector inference and exact interval purging."""
from __future__ import annotations

from typing import Any
import numpy as np
import pandas as pd


def purge_overlapping_intervals(train: pd.DataFrame, evaluation: pd.DataFrame) -> pd.DataFrame:
    """Closed information intervals intersect at equality; every overlap is purged."""
    if len(train) == 0 or len(evaluation) == 0:
        return train.copy()
    starts = pd.to_datetime(evaluation.feature_start, utc=True).astype('int64').to_numpy()
    ends = pd.to_datetime(evaluation.label_end, utc=True).astype('int64').to_numpy()
    order = np.argsort(starts)
    starts, ends = starts[order], ends[order]
    prefix_max_end = np.maximum.accumulate(ends)
    train_starts = pd.to_datetime(train.feature_start, utc=True).astype('int64').to_numpy()
    train_ends = pd.to_datetime(train.label_end, utc=True).astype('int64').to_numpy()
    positions = np.searchsorted(starts, train_ends, side='right')-1
    overlap = np.zeros(len(train), dtype=bool)
    valid = positions >= 0
    overlap[valid] = prefix_max_end[positions[valid]] >= train_starts[valid]
    return train.loc[~overlap].copy()


def eligible_block_starts(sessions: list[str], official_sessions: list[str], block: int) -> np.ndarray:
    if block < 1 or len(set(sessions)) != len(sessions) or sessions != sorted(sessions):
        raise ValueError('invalid_bootstrap_session_order')
    positions = {day:index for index,day in enumerate(official_sessions)}
    locs = np.array([positions[day] for day in sessions], dtype=np.int64)
    starts = [start for start in range(len(sessions)-block+1)
              if np.array_equal(locs[start:start+block],np.arange(locs[start],locs[start]+block))]
    return np.array(starts,dtype=np.int64)


def hac_mean_se(values: np.ndarray, positions: np.ndarray, block: int) -> np.ndarray:
    if values.ndim != 2 or len(values) != len(positions) or not np.isfinite(values).all():
        raise ValueError('invalid_contrast_matrix')
    if len(positions)==0 or not (np.diff(positions)>0).all():
        raise ValueError('invalid_contrast_calendar_order')
    total = len(values)
    centered = values-values.mean(axis=0)
    variance = np.sum(centered*centered,axis=0)/total
    for lag in range(1,block):
        # A calendar lag is not a row offset when certified sessions have gaps.
        later=np.searchsorted(positions,positions+lag)
        earlier=np.flatnonzero(later<len(positions))
        earlier=earlier[positions[later[earlier]]==positions[earlier]+lag]
        products=centered[later[earlier]]*centered[earlier]
        covariance = products.sum(axis=0)/total
        variance += 2*(1-lag/block)*covariance
    return np.sqrt(np.where(variance>0,variance/total,np.nan))


def simultaneous_lower_bounds(daily: pd.DataFrame, official_sessions: list[str], *,
                               block: int=5, draws: int=10000, seed: int=150,
                               minimum_sessions: int=60, minimum_nonzero: int=20,
                               confidence: float=.99) -> dict[str,Any]:
    sessions=list(daily.index.astype(str));columns=list(daily.columns)
    base={'complete_paired_sessions':len(sessions),'contrasts':len(columns),
          'block_sessions':block,'draws':draws,'seed':seed,'confidence_one_sided':confidence,
          'method':'null_centered_joint_session_block_max_fixed_original_HAC_SE',
          'minimum_nonzero_daily_contrasts':minimum_nonzero,
          'history_role':'reused_development_reference_not_fresh_confirmation'}
    if len(sessions)<minimum_sessions:
        return {**base,'status':'INSUFFICIENT_EVIDENCE','reason':'fewer_than_60_complete_daily_clusters',
                'lower_bounds':{column:None for column in columns}}
    starts=eligible_block_starts(sessions,official_sessions,block)
    base['eligible_block_starts']=int(len(starts))
    base['calendar_gaps']=int(sum(1 for left,right in zip(sessions,sessions[1:])
                                    if official_sessions.index(right)-official_sessions.index(left)!=1))
    supported=np.zeros(len(sessions),dtype=bool)
    for start in starts:
        supported[start:start+block]=True
    base['unsupported_sessions']=[sessions[i] for i in np.flatnonzero(~supported)]
    if len(starts)<20 or not supported.all():
        return {**base,'status':'INSUFFICIENT_EVIDENCE','reason':'insufficient_contiguous_block_support',
                'lower_bounds':{column:None for column in columns}}
    values=daily.to_numpy(dtype=float)
    if not np.isfinite(values).all():
        raise ValueError('unknown_daily_contrast_cannot_be_cash_zero')
    positions=np.array([official_sessions.index(day) for day in sessions])
    means=values.mean(axis=0);se=hac_mean_se(values,positions,block)
    nonzero=(values!=0).sum(axis=0)
    eligible=np.isfinite(se)&(se>0)&(nonzero>=minimum_nonzero)
    base['eligible_contrasts']=int(eligible.sum())
    if not eligible.any():
        return {**base,'status':'INSUFFICIENT_EVIDENCE','reason':'zero_or_unstable_daily_contrast_scale',
                'lower_bounds':{column:None for column in columns}}
    centered=values[:,eligible]-means[eligible]
    fixed_scale=se[eligible]
    rng=np.random.default_rng(seed)
    maxima=[]
    blocks_per_draw=(len(values)+block-1)//block
    for offset in range(0,draws,128):
        count=min(128,draws-offset)
        sampled=rng.choice(starts,size=(count,blocks_per_draw),replace=True)
        indices=(sampled[:,:,None]+np.arange(block)).reshape(count,-1)[:,:len(values)]
        bootstrap_means=centered[indices].mean(axis=1)
        maxima.extend((bootstrap_means/fixed_scale).max(axis=1).tolist())
    critical=float(np.quantile(np.asarray(maxima),confidence,method='linear'))
    lower=means-critical*se
    return {**base,'status':'REFERENCE_INFERENCE_ONLY','reason':None,'max_statistic_critical_value':critical,
            'lower_bounds':{column:float(lower[i]) if eligible[i] else None for i,column in enumerate(columns)},
            'mean_daily_differences':{column:float(means[i]) for i,column in enumerate(columns)},
            'hac_mean_standard_errors':{column:float(se[i]) if np.isfinite(se[i]) else None for i,column in enumerate(columns)},
            'nonzero_daily_contrasts':{column:int(nonzero[i]) for i,column in enumerate(columns)},
            'ineligible_reason':{column:None if eligible[i] else 'nonpositive_or_nonfinite_HAC_variance_or_sparse_series'
                                 for i,column in enumerate(columns)},
            'interpretation':'Relative improvement only; no absolute-profit or fresh-confirmation pass.'}
