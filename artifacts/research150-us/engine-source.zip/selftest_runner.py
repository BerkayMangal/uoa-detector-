"""End-to-end synthetic registry exercise; never opens historical market prices."""
from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import pandas as pd

import run_pilot
from research_engine import file_sha256, write_json
from selftest_engine import synthetic


class RunnerChecks(unittest.TestCase):
    def test_full_registry_metadata_seal_and_synthetic_output(self):
        with tempfile.TemporaryDirectory(prefix='research150_SYNTHETIC_ONLY_') as directory:
            root=Path(directory)
            (root/'bulk').mkdir()
            for document in run_pilot.DOCUMENTS:
                shutil.copyfile(run_pilot.ROOT/document,root/document)
            dates=['2026-01-02','2026-01-05']
            plan={'universe':list(run_pilot.UNIVERSE),
                  'sessions':[{'session':day} for day in dates],
                  'source':'SYNTHETIC_SELFTEST_ONLY'}
            write_json(root/'bulk/dataset-plan.json',plan)
            plan_hash=file_sha256(root/'bulk/dataset-plan.json')
            rows=[]
            for ticker in run_pilot.UNIVERSE:
                for day in dates:
                    path=root/'bulk'/f'{ticker}_{day}.csv.gz'
                    synthetic(ticker=ticker,session=day).to_csv(path,index=False,compression='gzip')
                    rows.append({'ticker':ticker,'session':day,'status':'complete',
                                 'plan_sha256':plan_hash,
                                 'canonical_path':str(path),'canonical_sha256':file_sha256(path),
                                 'source':{'kind':'SYNTHETIC_SELFTEST_ONLY',
                                           'received_at':'2026-11-12T00:00:00+00:00',
                                           'file_sha256':'synthetic_file_hash',
                                           'packet_hash':'synthetic_packet_hash',
                                           'raw_body_sha256':'synthetic_not_native'}})
            manifest=root/'bulk/coverage-manifest.json'
            write_json(manifest,{'statistics':{'plan_sha256':plan_hash},'sessions':rows})
            output=root/'SYNTHETIC_RESULTS_ONLY'
            with patch.object(run_pilot,'ROOT',root),contextlib.redirect_stdout(io.StringIO()):
                for corrupted in [
                    {'statistics':{'plan_sha256':'wrong'},'sessions':rows},
                    {'statistics':{'plan_sha256':plan_hash},'sessions':[{**rows[0],'plan_sha256':'wrong'},*rows[1:]]}
                ]:
                    write_json(root/'bad-manifest.json',corrupted)
                    with self.assertRaisesRegex(ValueError,'coverage_dataset_plan_hash_mismatch'):
                        run_pilot.metadata_seal(root/'INVALID_SEAL',root/'bad-manifest.json','all')
                run_pilot.metadata_seal(output,manifest,'all')
                self.assertFalse((output/'report.json').exists())
                self.assertFalse(json.loads((output/'run-seal.json').read_text())['price_labels_opened'])
                run_pilot.run(output)
                with self.assertRaisesRegex(ValueError,'outcomes_already_written'):
                    run_pilot.run(output)
            report=json.loads((output/'report.json').read_text())
            registry=json.loads((root/'pilot-registry-v2.json').read_text())
            self.assertEqual(report['evaluated_policy_count'],108)
            self.assertEqual(report['evaluated_policy_cost_views'],324)
            self.assertEqual(report['original_150_hypotheses_tested'],0)
            self.assertEqual(report['option_results'],'NOT_TESTED')
            results=json.loads((output/'per-trial-results.json').read_text())
            self.assertEqual({row['canonical_trial_id'] for row in results},
                             {row['trial_id'] for row in registry['trials']})
            self.assertEqual(len(results),324)
            self.assertTrue(all(row['overall']['complete_common_sessions']==2 for row in results))
            self.assertTrue(all(row['chronological_evaluation']['status']=='NO_COMPLETE_SESSIONS' for row in results))
            bounds=json.loads((output/'joint-block-inference.json').read_text())
            self.assertEqual(bounds['development']['5']['status'],'INSUFFICIENT_EVIDENCE')
            frames=[pd.read_parquet(path) for path in (output/'trades').glob('*.parquet')]
            trades=pd.concat(frames,ignore_index=True)
            self.assertGreater(len(trades),0)
            self.assertTrue(trades.source_raw_sha256.eq('synthetic_not_native').all())
            self.assertTrue(trades.source_file_sha256.eq('synthetic_file_hash').all())
            self.assertTrue(trades.source_packet_hash.eq('synthetic_packet_hash').all())
            self.assertTrue(trades.source_kind.eq('SYNTHETIC_SELFTEST_ONLY').all())
            self.assertTrue((trades.entry_at-trades.signal_at).eq(pd.Timedelta(minutes=1)).all())
            self.assertTrue((trades.feature_start<trades.signal_at).all())
            self.assertTrue(trades.availability_basis.eq('historical_event_time_proxy_not_contemporaneous_receipt').all())


if __name__=='__main__':
    unittest.main(verbosity=2)
