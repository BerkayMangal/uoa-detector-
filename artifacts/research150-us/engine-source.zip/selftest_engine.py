"""Synthetic causality/economics checks; does not access real market outcomes."""
from __future__ import annotations

import unittest
import numpy as np
import pandas as pd
from frozen_v2_features import build_features, registry, signal_rows
from research_engine import (Economics, aggregate_complete_bars, daily_portfolio, net_events,
                             priced_events, summary, validate_minutes)


def synthetic(ticker='SPY', session='2026-01-02', rows=390):
    start = pd.Timestamp(session+' 09:30', tz='America/New_York').tz_convert('UTC')
    times = pd.date_range(start, periods=rows, freq='min')
    index = np.arange(rows, dtype=float)
    opening = 100 + index*.01
    closing = opening + np.sin(index)*.02
    return pd.DataFrame({'ticker':ticker,'session':session,'start_time':times,
                         'end_time':times+pd.Timedelta(minutes=1),'open':opening,
                         'high':np.maximum(opening,closing)+.01,
                         'low':np.minimum(opening,closing)-.01,'close':closing,
                         'volume':100+(index%7)*5})


class EngineChecks(unittest.TestCase):
    def test_completed_aggregation_and_no_partial_bars(self):
        data=validate_minutes(synthetic())
        bars=aggregate_complete_bars(data,5)
        self.assertEqual(len(bars),78)
        self.assertEqual(bars.iloc[0].end_time,data.iloc[4].end_time)
        self.assertEqual(bars.iloc[0].close,data.iloc[4].close)
        with self.assertRaisesRegex(ValueError,'incomplete_session'):
            validate_minutes(synthetic().iloc[:-1])
        with self.assertRaisesRegex(ValueError,'duplicate_minute'):
            validate_minutes(pd.concat([synthetic(),synthetic().iloc[:1]]))

    def test_full_minute_embargo_and_exact_open_prices(self):
        data=validate_minutes(synthetic())
        signals=pd.DataFrame({'ticker':['SPY'],'session':['2026-01-02'],
                              'end_time':[data.iloc[0].end_time],'direction':[1]})
        event=priced_events(data,signals,1).iloc[0]
        self.assertEqual(event.entry_at,data.iloc[2].start_time)
        self.assertEqual(event.exit_at,data.iloc[3].start_time)
        self.assertEqual(event.entry_price,data.iloc[2].open)
        self.assertEqual(event.exit_price,data.iloc[3].open)
        self.assertAlmostEqual(event.gross_return,data.iloc[3].open/data.iloc[2].open-1)

    def test_missing_exact_entry_or_exit_is_not_filled(self):
        data=validate_minutes(synthetic())
        signals=pd.DataFrame({'ticker':['SPY'],'session':['2026-01-02'],
                              'end_time':[data.iloc[0].end_time],'direction':[1]})
        events=priced_events(data.drop(index=2),signals,1)
        self.assertFalse(events.selected.any())
        events=priced_events(data.drop(index=3),signals,1)
        self.assertFalse(events.selected.any())

    def test_nonoverlap_and_session_end_are_enforced(self):
        data=validate_minutes(synthetic())
        signals=pd.DataFrame({'ticker':['SPY']*4,'session':['2026-01-02']*4,
                              'end_time':data.iloc[[0,1,5,389]].end_time.tolist(),'direction':[1]*4})
        events=priced_events(data,signals,5)
        self.assertEqual(events.selected.tolist(),[True,False,True,False])
        self.assertEqual(events.eligible_quote_window.tolist(),[True,True,True,False])

    def test_cost_is_roundtrip_not_doubled_and_sides_are_signed(self):
        data=validate_minutes(synthetic())
        signal=pd.DataFrame({'ticker':['SPY'],'session':['2026-01-02'],
                             'end_time':[data.iloc[0].end_time],'direction':[1]})
        long=priced_events(data,signal,1)
        short=priced_events(data,signal.assign(direction=-1),1)
        self.assertAlmostEqual(long.iloc[0].gross_return,-short.iloc[0].gross_return)
        result=net_events(long,5)
        self.assertAlmostEqual(result.iloc[0].gross_return-result.iloc[0].net_return,.0005)
        self.assertAlmostEqual(net_events(long,20).iloc[0].net_return-result.iloc[0].net_return,-.0015)

    def test_future_data_does_not_change_earlier_features_or_signals(self):
        data=validate_minutes(synthetic())
        baseline=build_features(aggregate_complete_bars(data,1))
        changed=data.copy()
        changed.loc[120:,['open','high','low','close']]*=4
        changed.loc[120:,'volume']*=100
        later=build_features(aggregate_complete_bars(changed,1))
        pd.testing.assert_frame_equal(baseline.iloc[:120],later.iloc[:120])
        for family in ['H138_US_V2','H142_US_V2','H145_US_V2']:
            before=signal_rows(baseline.iloc[:120],family,'long','candidate')
            after=signal_rows(later.iloc[:120],family,'long','candidate')
            pd.testing.assert_frame_equal(before,after)

    def test_features_reset_each_session_and_need_nine_previous_bars(self):
        data=validate_minutes(pd.concat([synthetic(),synthetic(session='2026-01-05')]))
        f=build_features(aggregate_complete_bars(data,1))
        second=f[f.session=='2026-01-05'].reset_index(drop=True)
        self.assertTrue(second.iloc[:9].warmup9.eq(False).all())
        self.assertTrue(second.iloc[9:].warmup9.eq(True).all())
        self.assertTrue(second.iloc[:8].r_mean_prior8.isna().all())

    def test_exact_frozen_formulas_exclude_current_bar(self):
        f=build_features(aggregate_complete_bars(validate_minutes(synthetic()),1))
        k=20
        self.assertAlmostEqual(f.iloc[k].v_q10_older8,np.quantile(f.v.iloc[k-9:k-1],.1,method='linear'))
        self.assertAlmostEqual(f.iloc[k].prior_high4,f.high.iloc[k-4:k].max())
        prior=f.r.iloc[k-8:k]
        self.assertAlmostEqual(f.iloc[k].z,(f.r.iloc[k]-prior.mean())/prior.std(ddof=1))
        corr=np.corrcoef(f.r.iloc[k-8:k],f.log_volume.iloc[k-8:k])[0,1]
        self.assertAlmostEqual(f.iloc[k].corr_prior8,corr)
        self.assertAlmostEqual(f.iloc[k].momentum3,np.log(f.close.iloc[k]/f.close.iloc[k-3]))

    def test_zero_variance_correlations_are_ineligible_and_registry_is_complete(self):
        raw=synthetic();raw['volume']=100
        f=build_features(aggregate_complete_bars(validate_minutes(raw),1))
        for role in ('candidate','baseline'):
            self.assertEqual(len(signal_rows(f,'H145_US_V2','long',role)),0)
        entries=registry()
        self.assertEqual(len(entries),324)
        self.assertEqual(len({x['path_id'] for x in entries}),108)
        self.assertEqual(len({x['contrast_id'] for x in entries}),54)

    def test_daily_cash_zero_only_on_certified_days_and_drawdown_includes_initial_equity(self):
        events=pd.DataFrame({'session':['2026-01-02'],'net_return':[-.09],
                             'gross_return':[-.0895],'direction':[1]})
        daily=daily_portfolio(events,('2026-01-02','2026-01-05'))
        self.assertEqual(list(daily),[-.01,0])
        result=summary(events,('2026-01-02','2026-01-05'))
        self.assertAlmostEqual(result['max_daily_equity_drawdown'],-.01)
        self.assertEqual(summary(events,())['status'],'NO_COMPLETE_SESSIONS')


if __name__=='__main__':
    unittest.main(verbosity=2)
