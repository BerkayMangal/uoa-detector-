"""Seal metadata before opening labels, then run the exact frozen price pilot.

Example (metadata only): python run_pilot.py --seal-only --output /path/run
Then, only after authorization: python run_pilot.py --run --output /path/run
No network, fits, optimization, strategy edits, option-return substitution or protected labels.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path
import json
import hashlib
import sys
from importlib.metadata import version
from collections import Counter, defaultdict

import numpy as np
import pandas as pd

from frozen_v2_features import build_features, signal_rows
from inference import purge_overlapping_intervals, simultaneous_lower_bounds
from research_engine import (Economics, aggregate_complete_bars, daily_portfolio,
                             file_sha256, load_canonical, net_events, priced_events, summary, write_json)

ROOT=Path(__file__).resolve().parents[1]
ENGINE=Path(__file__).resolve().parent
DOCUMENTS=('pilot-protocol-v2.md','pilot-registry-v2.json','pilot-v2-implementation-clarification.md',
           'pilot-v2-inference-gates.md','pilot-freeze-v2.json')
CODE=('research_engine.py','frozen_v2_features.py','inference.py','run_pilot.py','selftest_engine.py','selftest_inference.py','selftest_runner.py')
UNIVERSE=('SPY','QQQ','AAPL','NFLX','NVDA','TSLA','MSFT','META','AMZN')


def metadata_seal(output:Path, manifest:Path, phase:str)->None:
    output.mkdir(parents=True,exist_ok=True)
    if (output/'run-seal.json').exists():
        raise ValueError('seal_already_exists_use_new_run_directory')
    registry=json.loads((ROOT/'pilot-registry-v2.json').read_text())
    plan_bytes=(ROOT/'bulk/dataset-plan.json').read_bytes()
    plan=json.loads(plan_bytes)
    plan_sha256=hashlib.sha256(plan_bytes).hexdigest()
    coverage=json.loads(manifest.read_text())
    if (coverage.get('statistics',{}).get('plan_sha256')!=plan_sha256 or
            any(row.get('plan_sha256')!=plan_sha256 for row in coverage['sessions'])):
        raise ValueError('coverage_dataset_plan_hash_mismatch')
    if tuple(registry['universe'])!=UNIVERSE or tuple(plan['universe'])!=UNIVERSE:
        raise ValueError('frozen_universe_mismatch')
    frozen=json.loads((ROOT/'pilot-freeze-v2.json').read_text())
    for name,checksum in frozen['files'].items():
        if file_sha256(ROOT/name)!=checksum:raise ValueError('frozen_protocol_hash_mismatch')
    write_json(output/'input-coverage-manifest.json',coverage)
    write_json(output/'input-dataset-plan.json',plan)
    seal={'created_at':datetime.now(timezone.utc).isoformat(),'phase':phase,
          'price_labels_opened':False,'universe':list(UNIVERSE),
          'runtime':{'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'pyarrow':version('pyarrow')},
          'source_dataset_plan_sha256':plan_sha256,
          'documents':{name:file_sha256(ROOT/name) for name in DOCUMENTS},
          'code':{name:file_sha256(ENGINE/name) for name in CODE},
          'inputs':{name:file_sha256(output/name) for name in ('input-coverage-manifest.json','input-dataset-plan.json')},
          'original_manifest_path':str(manifest),'original_manifest_sha256':file_sha256(manifest),
          'labels_access_policy':'Only certified full-nine-symbol common sessions in sealed phase; no separately protected study files.'}
    write_json(output/'run-seal.json',seal)
    print(json.dumps({'status':'SEALED_NO_LABELS_OPENED','path':str(output/'run-seal.json'),
                      'seal_sha256':file_sha256(output/'run-seal.json')}),flush=True)


def period_summary(events:pd.DataFrame, dates:list[str], expected:list[str])->dict:
    chosen=events[events.session.isin(dates)]
    result=summary(chosen,tuple(dates))
    result.update({'expected_sessions':len(expected),'complete_common_sessions':len(dates),
                   'coverage_ratio':len(dates)/len(expected) if expected else None,
                   'missing_sessions':sorted(set(expected)-set(dates)),
                   'inference_disposition':'DESCRIPTIVE_ONLY' if len(dates) else 'BLOCKED_DATA'})
    daily=daily_portfolio(chosen,tuple(dates))
    if len(dates):
        best=str(daily.idxmax())
        result['largest_gain_day']=best
        result['leave_largest_gain_day_out_additive_return']=float(daily.drop(best).sum())
        by_symbol=chosen.groupby('ticker').net_return.sum().div(9)
        result['symbol_additive_contributions']={symbol:float(by_symbol.get(symbol,0)) for symbol in UNIVERSE}
        result['leave_one_symbol_out_additive_return']={symbol:float(daily.sum()-by_symbol.get(symbol,0)) for symbol in UNIVERSE}
        absolute=float(by_symbol.abs().sum())
        result['max_absolute_symbol_contribution_share']=float(by_symbol.abs().max()/absolute) if absolute else None
        dayabsolute=float(daily.abs().sum())
        result['max_absolute_day_contribution_share']=float(daily.abs().max()/dayabsolute) if dayabsolute else None
    return result


def run(output:Path)->None:
    seal=json.loads((output/'run-seal.json').read_text())
    for group,base in [('documents',ROOT),('code',ENGINE),('inputs',output)]:
        for name,checksum in seal[group].items():
            if file_sha256(base/name)!=checksum:raise ValueError('run_seal_hash_mismatch:'+group+':'+name)
    if (output/'report.json').exists():raise ValueError('outcomes_already_written_do_not_silently_overwrite')
    registry=json.loads((ROOT/'pilot-registry-v2.json').read_text())
    plan=json.loads((output/'input-dataset-plan.json').read_text())
    manifest=json.loads((output/'input-coverage-manifest.json').read_text())
    official=[row['session'] for row in plan['sessions']]
    if seal['phase']=='development':expected=[day for day in official if day<'2026-10-01']
    elif seal['phase']=='chronological_evaluation':expected=[day for day in official if day>='2026-10-01']
    else:expected=official
    certified=[row for row in manifest['sessions'] if row['status']=='complete' and row['session'] in expected
               and row['ticker'] in UNIVERSE]
    by_day=defaultdict(set)
    for row in certified:by_day[row['session']].add(row['ticker'])
    common=sorted(day for day,symbols in by_day.items() if symbols==set(UNIVERSE))
    chosen=[row for row in certified if row['session'] in common]
    coverage={'expected_sessions':len(expected),'expected_ticker_sessions':len(expected)*9,
              'certified_ticker_sessions':len(certified),'complete_nine_symbol_sessions':len(common),
              'common_dates':common,'excluded_sessions':sorted(set(expected)-set(common)),
              'ticker_session_status_counts':dict(Counter(row['status'] for row in manifest['sessions'] if row['session'] in expected)),
              'physical_receipts':[{k:row[k] for k in ('ticker','session','source','canonical_sha256') if k in row} for row in chosen],
              'signal_clock':'native completed bar end plus declared one-minute latency; historical availability unproven',
              'physical_availability_clock':'source received_at from retained collector receipts; never backdated to bar end',
              'session_selection_basis':'retrospective whole-session data-quality filter, including minutes after signal; not a live-known eligibility rule'}
    write_json(output/'analysis-coverage.json',coverage)
    if not common:
        write_json(output/'report.json',{'status':'BLOCKED_DATA','coverage':coverage,'evaluated_policy_count':0,
                                         'reason':'no_complete_fixed_nine_symbol_session','price_labels_opened':False})
        return
    paths=[Path(row['canonical_path']) for row in chosen]
    hashes={row['canonical_path']:row['canonical_sha256'] for row in chosen}
    minutes=load_canonical(paths,expected_hashes=hashes)
    features={width:build_features(aggregate_complete_bars(minutes,width)) for width in (1,5,15)}
    for width,frame in features.items():
        # Earliest actual raw input: nine prior bars plus the entire current bar.
        frame['feature_start']=frame.groupby(['ticker','session'],sort=False).start_time.shift(9)
        frame.to_parquet(output/f'features_{width}m.parquet',index=False)
    (output/'trades').mkdir(exist_ok=True)
    results=[];monthly=[];matrices={cost:{} for cost in (5,10,20)};intervals=[];run_registry=[]
    for number,trial in enumerate(registry['trials']):
        path_id=trial['trial_id'];width=trial['bar_minutes'];horizon=trial['holding_minutes']
        frame=features[width]
        signals=signal_rows(frame,trial['family'],trial['side'],trial['arm'])
        events=priced_events(minutes,signals,horizon)
        events=events.merge(frame[['ticker','session','end_time','feature_start']],how='left',
                            left_on=['ticker','session','signal_at'],right_on=['ticker','session','end_time'],validate='many_to_one')
        events['label_end']=events.exit_at
        provenance=pd.DataFrame([{'ticker':row['ticker'],'session':row['session'],
                                   'source_kind':row.get('source',{}).get('kind'),
                                   'source_received_at':row.get('source',{}).get('received_at'),
                                   'source_raw_sha256':row.get('source',{}).get('raw_body_sha256'),
                                   'source_file_sha256':row.get('source',{}).get('file_sha256'),
                                   'source_packet_hash':row.get('source',{}).get('packet_hash'),
                                   'canonical_file_sha256':row['canonical_sha256']} for row in chosen])
        events=events.merge(provenance,how='left',on=['ticker','session'],validate='many_to_one')
        events['availability_basis']='historical_event_time_proxy_not_contemporaneous_receipt'
        selected=events[events.selected].copy()
        selected.to_parquet(output/'trades'/f'{path_id}.parquet',index=False)
        intervals.append(selected[['session','feature_start','label_end']])
        for cost in trial['stock_cost_bps_roundtrip']:
            net=net_events(events,cost)
            view_id=f'{path_id}_cost{cost:02d}'
            matrices[cost][path_id]=daily_portfolio(net,tuple(common))
            per={'trial_id':view_id,'canonical_trial_id':path_id,'family':trial['family'],
                 'side':trial['side'],'role':trial['arm'],'timeframe_minutes':width,'horizon_minutes':horizon,
                 'roundtrip_cost_bps':cost,'signals':len(signals),
                 'unpriceable_signal_windows':int((~events.eligible_quote_window).sum()),
                 'overlap_suppressed_signals':int((events.eligible_quote_window&~events.selected).sum()),
                 'overall':period_summary(net,common,expected)}
            for label,condition in [('development',lambda day:day<'2026-10-01'),
                                    ('chronological_evaluation',lambda day:day>='2026-10-01')]:
                per[label]=period_summary(net,[day for day in common if condition(day)],
                                          [day for day in expected if condition(day)])
            results.append(per)
            for month in [f'2026-{value:02d}' for value in range(1,12)]:
                dates=[day for day in common if day.startswith(month)]
                target=[day for day in expected if day.startswith(month)]
                if target:monthly.append({'trial_id':view_id,'canonical_trial_id':path_id,'month':month,
                                          **period_summary(net,dates,target)})
            run_registry.append({**trial,'evaluated':True,'outcomes_inspected':True,'policy_cost_view_id':view_id,
                                 'roundtrip_cost_bps':cost,'result_path':'per-trial-results.json'})
        if (number+1)%18==0:print(json.dumps({'status':'RUNNING','policies_done':number+1,'policies_total':108}),flush=True)
    daily_frames={cost:pd.DataFrame(columns).reindex(common) for cost,columns in matrices.items()}
    for cost,frame in daily_frames.items():
        frame.index.name='session';frame.to_parquet(output/f'daily_proxy_returns_cost{cost:02d}.parquet')
    contrasts=[];contrast_frames={}
    for cost,frame in daily_frames.items():
        columns={}
        for trial in registry['trials']:
            if trial['arm']!='candidate':continue
            path_id=trial['trial_id'];contrast_id=path_id.removesuffix('_candidate')
            values=frame[path_id]-frame[trial['baseline_id']];columns[contrast_id]=values
            for label,condition in [('development',lambda day:day<'2026-10-01'),
                                    ('chronological_evaluation',lambda day:day>='2026-10-01')]:
                dates=[day for day in common if condition(day)];subset=values.reindex(dates)
                contrasts.append({'contrast_id':contrast_id,'roundtrip_cost_bps':cost,'period':label,
                                  'complete_paired_sessions':len(dates),
                                  'mean_daily_difference':float(subset.mean()) if len(dates) else None,
                                  'additive_paired_difference':float(subset.sum()) if len(dates) else None,
                                  'inference':'DESCRIPTIVE_ONLY' if len(dates) else 'BLOCKED_DATA'})
        contrast_frames[cost]=pd.DataFrame(columns).reindex(common)
    inference={}
    for label,condition in [('development',lambda day:day<'2026-10-01'),
                            ('chronological_evaluation',lambda day:day>='2026-10-01')]:
        data=contrast_frames[5].loc[[day for day in common if condition(day)]]
        inference[label]={str(block):simultaneous_lower_bounds(data,official,block=block) for block in (5,10)}
    all_intervals=pd.concat(intervals,ignore_index=True).drop_duplicates()
    folds=[]
    for month in range(4,10):
        first=f'2026-{month:02d}-01';next_month=f'2026-{month+1:02d}-01'
        training=all_intervals[all_intervals.session<first]
        evaluation=all_intervals[(all_intervals.session>=first)&(all_intervals.session<next_month)]
        purged=purge_overlapping_intervals(training,evaluation)
        expected_train=[day for day in official if day<first]
        expected_eval=[day for day in official if first<=day<next_month]
        observed_train=[day for day in common if day<first]
        observed_eval=[day for day in common if first<=day<next_month]
        complete=set(expected_train)<=set(observed_train) and set(expected_eval)<=set(observed_eval)
        folds.append({'evaluation_month':first[:7],'training_expected_sessions':len(expected_train),
                      'training_complete_sessions':len(observed_train),'evaluation_expected_sessions':len(expected_eval),
                      'evaluation_complete_sessions':len(observed_eval),'training_intervals_before_purge':len(training),
                      'training_intervals_after_purge':len(purged),'purged_intervals':len(training)-len(purged),
                      'fitted_parameters':0,'status':'FIXED_RULE_REFERENCE_FOLD' if complete else 'BLOCKED_DATA',
                      'availability_basis':'event_time_proxy; physical historical fitting not claimed'})
    write_json(output/'per-trial-results.json',results);write_json(output/'per-month-results.json',monthly)
    write_json(output/'evaluated-registry.json',run_registry);write_json(output/'paired-contrasts.json',contrasts)
    write_json(output/'joint-block-inference.json',inference);write_json(output/'purged-folds.json',folds)
    report={'status':'DESCRIPTIVE_ONLY','coverage':coverage,'evaluated_policy_count':108,
            'evaluated_policy_cost_views':324,'paired_contrast_count':54,'paired_cost_views':162,
            'original_150_hypotheses_tested':0,'us_price_proxy_adaptations_tested':3,
            'code_and_data_seal_sha256':file_sha256(output/'run-seal.json'),
            'chronological_evaluation_label':registry['final_evaluation_label'],
            'dsr':'INSUFFICIENT_EVIDENCE','dsr_reason':'full prior search history and untouched confirmation absent',
            'option_results':'NOT_TESTED','news_predictive_filters':'NOT_TESTED',
            'reference_notional_usd':10000,'economic_basis':'equal fixed1/9 stock sleeves; constant-notional daily return proxy',
            'price_labels_opened':True,'first_complete_session':common[0],'last_complete_session':common[-1],
            'artifacts':{name:file_sha256(output/name) for name in ['per-trial-results.json','per-month-results.json',
               'evaluated-registry.json','paired-contrasts.json','joint-block-inference.json','purged-folds.json']},
            'limitations':['No bid/ask execution proof. Costs are assumed roundtripstockbps.',
                           'Short locate and borrow availability/cost are unverified.',
                           'Historical downloads do not establish contemporary system availability.',
                           'Complete-session certification examines later minutes; nonrandom quality exclusions limit generalization to all live sessions.',
                           'Chronological evaluation is partly previously observed and cannot confirm a new edge.',
                           'Sessions without nine certified symbol streams remain excluded/UNKNOWN; invalid native volume is distinct from absent timestamp packets; no capital redistribution.',
                           'All registry variants retained; no selected winner or live strategy change.']}
    write_json(output/'report.json',report)
    print(json.dumps({'status':report['status'],'policies':108,'cost_views':324,'common_sessions':len(common),
                      'output':str(output)}),flush=True)


def main()->None:
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--manifest',type=Path,default=ROOT/'bulk/coverage-manifest.json')
    parser.add_argument('--phase',choices=['development','chronological_evaluation','all'],default='all')
    group=parser.add_mutually_exclusive_group(required=True);group.add_argument('--seal-only',action='store_true');group.add_argument('--run',action='store_true')
    args=parser.parse_args()
    if args.seal_only:metadata_seal(args.output,args.manifest,args.phase)
    else:run(args.output)

if __name__=='__main__':main()
