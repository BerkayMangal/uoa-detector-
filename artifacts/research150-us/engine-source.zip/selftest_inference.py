"""Synthetic-only checks for registered joint inference and interval purge."""
from __future__ import annotations

import unittest
import numpy as np
import pandas as pd
from inference import eligible_block_starts, hac_mean_se, purge_overlapping_intervals, simultaneous_lower_bounds


def dates(count=160):return pd.bdate_range('2026-01-02',periods=count).strftime('%Y-%m-%d').tolist()


class InferenceChecks(unittest.TestCase):
    def test_exact_closed_information_interval_purge(self):
        train=pd.DataFrame({'feature_start':pd.to_datetime(['2026-01-01T10:00Z','2026-01-02T10:00Z','2026-01-03T10:00Z']),
                            'label_end':pd.to_datetime(['2026-01-01T11:00Z','2026-01-02T11:00Z','2026-01-03T11:00Z'])})
        evaluation=pd.DataFrame({'feature_start':pd.to_datetime(['2026-01-02T11:00Z']),
                                 'label_end':pd.to_datetime(['2026-01-03T10:30Z'])})
        keep=purge_overlapping_intervals(train,evaluation)
        self.assertEqual(keep.index.tolist(),[0])

    def test_whole_session_reset_can_correctly_purge_zero(self):
        train=pd.DataFrame({'feature_start':pd.to_datetime(['2026-01-02T14:30Z']),
                            'label_end':pd.to_datetime(['2026-01-02T20:59Z'])})
        evaluation=pd.DataFrame({'feature_start':pd.to_datetime(['2026-01-05T14:30Z']),
                                 'label_end':pd.to_datetime(['2026-01-05T20:59Z'])})
        self.assertEqual(len(purge_overlapping_intervals(train,evaluation)),1)

    def test_blocks_never_stitch_a_missing_calendar_session(self):
        official=dates(20);available=official[:6]+official[7:]
        starts=eligible_block_starts(available,official,5)
        for start in starts:
            positions=[official.index(day) for day in available[start:start+5]]
            self.assertEqual(positions,list(range(positions[0],positions[0]+5)))

    def test_hac_bartlett_matches_hand_formula(self):
        values=np.array([1.,2.,1.,4.,2.,-1.])[:,None]
        centered=values[:,0]-values[:,0].mean();n=len(centered);block=3
        variance=np.sum(centered**2)/n
        for lag in range(1,block):
            variance+=2*(1-lag/block)*np.sum(centered[lag:]*centered[:-lag])/n
        self.assertAlmostEqual(hac_mean_se(values,np.arange(n),block)[0],np.sqrt(variance/n))

    def test_less_than_sixty_sessions_has_no_inferential_pass(self):
        all_dates=dates(59);frame=pd.DataFrame({'A':np.arange(59)/10000},index=all_dates)
        got=simultaneous_lower_bounds(frame,all_dates,draws=100)
        self.assertEqual(got['status'],'INSUFFICIENT_EVIDENCE')
        self.assertIsNone(got['lower_bounds']['A'])

    def test_hac_calendar_lags_across_missing_rows_match_pair_enumeration(self):
        positions=np.array([0,1,3,4,7,8,9,11])
        values=np.array([1.,2.,1.,4.,2.,-1.,3.,2.])[:,None]
        centered=values[:,0]-values[:,0].mean();n=len(values);block=5
        variance=np.sum(centered**2)/n
        for lag in range(1,block):
            covariance=sum(centered[i]*centered[j] for i in range(n) for j in range(n)
                           if positions[j]-positions[i]==lag)/n
            variance+=2*(1-lag/block)*covariance
        self.assertAlmostEqual(hac_mean_se(values,positions,block)[0],np.sqrt(variance/n))

    def test_isolated_available_day_prevents_resampling_a_different_population(self):
        official=dates(160);available=official[:50]+official[60:61]+official[70:120]
        frame=pd.DataFrame({'A':np.random.default_rng(1).normal(0,.001,len(available))},index=available)
        got=simultaneous_lower_bounds(frame,official,draws=100)
        self.assertEqual(got['status'],'INSUFFICIENT_EVIDENCE')
        self.assertIn(official[60],got['unsupported_sessions'])

    def test_joint_resampling_preserves_perfect_cross_trial_dependence(self):
        official=dates(80);value=np.random.default_rng(2).normal(.00005,.001,80)
        frame=pd.DataFrame({'A':value,'B':value*2,'ZERO':np.zeros(80)},index=official)
        got=simultaneous_lower_bounds(frame,official,draws=1000)
        again=simultaneous_lower_bounds(frame,official,draws=1000)
        self.assertEqual(got,again)
        self.assertEqual(got['eligible_contrasts'],2)
        self.assertIsNone(got['lower_bounds']['ZERO'])
        self.assertAlmostEqual(got['lower_bounds']['B'],2*got['lower_bounds']['A'])
        self.assertEqual(got['status'],'REFERENCE_INFERENCE_ONLY')

    def test_sparse_contrast_not_rescued_by_tiny_standard_error(self):
        official=dates(80);value=np.zeros(80);value[:19]=.001
        got=simultaneous_lower_bounds(pd.DataFrame({'SPARSE':value},index=official),official,draws=100)
        self.assertEqual(got['status'],'INSUFFICIENT_EVIDENCE')
        self.assertIsNone(got['lower_bounds']['SPARSE'])


if __name__=='__main__':unittest.main(verbosity=2)
