"""Exactly the three frozen v2 US price proxies; no tuning or fitted thresholds."""
from __future__ import annotations

import numpy as np
import pandas as pd

FAMILIES = ('H138_US_V2', 'H142_US_V2', 'H145_US_V2')


def build_features(bars: pd.DataFrame) -> pd.DataFrame:
    frame = bars.sort_values(['ticker', 'session', 'bar_index']).reset_index(drop=True).copy()
    frame['r'] = np.log(frame.close / frame.open)
    frame['v'] = np.log(frame.high / frame.low).pow(2) / (4 * np.log(2))
    frame['log_volume'] = np.log1p(frame.volume)
    keys = ['ticker', 'session']
    grouped = frame.groupby(keys, sort=False)
    frame['warmup9'] = grouped.cumcount() >= 9
    frame['v_previous'] = grouped.v.shift(1)
    frame['v_q10_older8'] = grouped.v.transform(
        lambda x: x.shift(2).rolling(8, min_periods=8).quantile(0.10, interpolation='linear'))
    frame['prior_high4'] = grouped.high.transform(lambda x: x.shift(1).rolling(4, min_periods=4).max())
    frame['prior_low4'] = grouped.low.transform(lambda x: x.shift(1).rolling(4, min_periods=4).min())
    frame['r_mean_prior8'] = grouped.r.transform(lambda x: x.shift(1).rolling(8, min_periods=8).mean())
    frame['r_sd_prior8'] = grouped.r.transform(lambda x: x.shift(1).rolling(8, min_periods=8).std(ddof=1))
    frame['volume_sd_prior8'] = grouped.log_volume.transform(
        lambda x: x.shift(1).rolling(8, min_periods=8).std(ddof=1))
    frame['z'] = (frame.r - frame.r_mean_prior8).div(frame.r_sd_prior8.replace(0, np.nan))
    frame['momentum3'] = np.log(frame.close / grouped.close.shift(3))
    frame['corr_prior8'] = np.nan
    for _, indices in grouped.indices.items():
        group = frame.loc[indices]
        correlation = group.r.shift(1).rolling(8, min_periods=8).corr(group.log_volume.shift(1))
        frame.loc[indices, 'corr_prior8'] = correlation.to_numpy()
    return frame


def signal_rows(features: pd.DataFrame, family: str, side: str, role: str) -> pd.DataFrame:
    if family not in FAMILIES or side not in ('long', 'short') or role not in ('candidate', 'baseline'):
        raise ValueError('unregistered_signal_specification')
    sign = 1 if side == 'long' else -1
    eligible = features.warmup9.copy()
    if family == 'H138_US_V2':
        eligible &= features[['v_previous', 'v_q10_older8', 'prior_high4', 'prior_low4']].notna().all(axis=1)
        baseline = features.close > features.prior_high4 if sign == 1 else features.close < features.prior_low4
        candidate = baseline & (features.v_previous <= features.v_q10_older8)
    elif family == 'H142_US_V2':
        eligible &= features[['z', 'r_mean_prior8', 'r_sd_prior8']].notna().all(axis=1) & (features.r_sd_prior8 > 0)
        baseline = features.r < 0 if sign == 1 else features.r > 0
        candidate = features.z <= -3 if sign == 1 else features.z >= 3
    else:
        eligible &= features[['momentum3', 'corr_prior8', 'r_sd_prior8', 'volume_sd_prior8']].notna().all(axis=1)
        eligible &= (features.r_sd_prior8 > 0) & (features.volume_sd_prior8 > 0)
        baseline = (sign * features.momentum3 > 0) & (sign * features.r > 0)
        candidate = baseline & (sign * features.corr_prior8 > 0)
    mask = eligible & (candidate if role == 'candidate' else baseline)
    output = features.loc[mask, ['ticker', 'session', 'end_time']].copy()
    output['direction'] = sign
    return output


def registry() -> list[dict[str, object]]:
    trials = []
    for family in FAMILIES:
        for side in ('long', 'short'):
            for timeframe in (1, 5, 15):
                for horizon in (1, 5, 15):
                    contrast = f'{family}_b{timeframe:02d}_h{horizon:02d}_{side}'
                    for role in ('candidate', 'baseline'):
                        path_id = f'{contrast}_{role}'
                        for cost in (5, 10, 20):
                            trials.append({'trial_id': f'{path_id}_cost{cost:02d}', 'canonical_trial_id': path_id, 'path_id': path_id,
                                           'contrast_id': contrast, 'family': family, 'side': side,
                                           'timeframe_minutes': timeframe, 'horizon_minutes': horizon,
                                           'role': role, 'roundtrip_cost_bps': cost})
    assert len(trials) == 324
    assert len({trial['path_id'] for trial in trials}) == 108
    return trials
