"""Synthetic, local-only evidence of full-export query growth; no provider data."""
from __future__ import annotations

import copy
import hashlib
import json
import sys
import tempfile
import time
from collections import Counter
from datetime import timedelta
from pathlib import Path

REPO = Path('/workspace/uoa-detector-')
sys.path[:0] = [str(REPO), str(REPO / 'src')]

from sqlalchemy import event
from tests.unit.test_news_adapter import LIVE, NOW, scan, snapshot
from webapp import news_export
from webapp.board.db import make_engine
from webapp.live_alpha import store
from webapp.news_research import storage

OUT = Path(__file__).parent
SYMBOLS = ('SPY', 'QQQ', 'AAPL', 'NFLX', 'NVDA', 'TSLA', 'MSFT', 'META', 'AMZN')


def measure(scan_count: int) -> dict:
    with tempfile.TemporaryDirectory(prefix='news-export-synthetic-') as directory:
        engine = make_engine(f'sqlite:///{directory}/local.db')
        store.ensure_live_tables(engine)
        storage.ensure(engine)
        checked = NOW - timedelta(seconds=30)
        for ticker in SYMBOLS:
            storage.append(engine, ticker, {'data': [{
                'headline': 'Synthetic fixture only', 'source': 'TEST', 'tickers': [ticker],
                'created_at': (NOW - timedelta(hours=1)).isoformat(),
            }]}, checked, NOW - timedelta(seconds=20),
                clock=lambda: NOW-timedelta(seconds=10), application_checked_at=checked)
        for index in range(scan_count):
            at = NOW + timedelta(seconds=index)
            data = snapshot(at)
            original = copy.deepcopy(data)
            data['flow_observations'] = {ticker: copy.deepcopy(original['flow_observations']['NVDA']) for ticker in SYMBOLS}
            data['news_observations'] = {ticker: {'state': 'checked_found', 'checked_at': checked.isoformat()} for ticker in SYMBOLS}
            data['news_research_context']['prices'] = {ticker: copy.deepcopy(original['news_research_context']['prices']['NVDA']) for ticker in SYMBOLS}
            scan(engine, str(index).zfill(4), at, data)
        queries = Counter()
        sql_seconds = 0.0
        starts = []

        def before(_conn, _cur, statement, *_args):
            upper = statement.upper()
            if 'SQLITE_MASTER' in upper:
                kind = 'table_introspection'
            elif 'ALFA_NEWS_RESEARCH_PACKET' in upper:
                kind = 'news_packet_select'
            elif 'ALFA_NEWS_RESEARCH_RECEIPT' in upper:
                kind = 'news_receipt_select'
            elif 'ALFA_LIVE_SCAN' in upper:
                kind = 'scan_select_or_aggregate'
            else:
                kind = 'other'
            queries[kind] += 1
            starts.append(time.perf_counter())

        def after(*_args):
            nonlocal sql_seconds
            sql_seconds += time.perf_counter() - starts.pop()

        event.listen(engine, 'before_cursor_execute', before)
        event.listen(engine, 'after_cursor_execute', after)
        started = time.perf_counter()
        result = news_export.export_session(engine, NOW.date(), NOW + timedelta(days=2))
        elapsed = time.perf_counter() - started
        engine.dispose()
        return {
            'scan_count': scan_count, 'ticker_count': len(SYMBOLS),
            'source_characters': result.source_characters,
            'opportunities': len(result.audit.dataset.opportunities),
            'news_provenance_records': len(result.audit.news_provenance),
            'unique_packet_keys': len({r.packet_key for r in result.audit.news_provenance}),
            'sql_counts': dict(queries), 'sql_count': sum(queries.values()),
            'local_sqlite_elapsed_seconds': round(elapsed, 6),
            'cursor_execute_seconds': round(sql_seconds, 6),
            'production_latency_estimate': None,
        }


def main():
    results = [measure(count) for count in (1, 4, 16, 64)]
    files = ['webapp/news_export.py', 'webapp/news_research/adapter.py',
             'webapp/news_research/storage.py', 'webapp/live_alpha/store.py']
    body = {
        'evidence_class': 'SYNTHETIC_LOCAL_ONLY_NOT_PRODUCTION_TIMING',
        'method': 'Unchanged export_session on isolated temporary SQLite, nine symbols sharing nine immutable packets across increasing completed scan counts; all fixture rows removed after each run.',
        'network_requests': 0, 'repository_files_modified': 0,
        'source_sha256': {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in files},
        'measurements': results,
        'interpretation': 'Every eligible scan/ticker repeats schema introspection, top-two packet select and receipt select even when the nine packet identities are unchanged. SQLite elapsed time is not a production speed estimate.',
    }
    (OUT / 'export-local-profile.json').write_text(json.dumps(body, indent=2) + '\n')
    print(json.dumps(body, indent=2))


if __name__ == '__main__':
    main()
