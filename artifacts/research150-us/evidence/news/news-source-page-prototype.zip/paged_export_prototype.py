"""WORK-ONLY source projection prototype. No route, provider calls, or strategy evaluation.

Uses existing immutable scan/packet tables. Do not deploy without the accompanying
proposal's PostgreSQL timeout, response cap, and integration checks.
"""
from __future__ import annotations

import base64
import gzip
import hashlib
import hmac
import io
import json
from datetime import datetime

from sqlalchemy import and_, func, literal, select, union_all
from webapp.board.db import session_factory
from webapp.live_alpha.store import LiveScan
from webapp.news_export import bounds
from webapp.news_research.storage import Packet, Receipt, signature
from webapp.opening.model import utc

VERSION = 'physical_news_source_pages_prototype_v1'
MAX_SCANS = 8
MAX_TICKERS = 9
MAX_DAY_SCANS = 256


class Refused(ValueError):
    pass


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _seal(body, key):
    raw = _json(body).encode()
    tag = hmac.new(key, raw, hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(raw).decode() + '.' + tag


def _open(cursor, key):
    try:
        encoded, tag = cursor.split('.')
        raw = base64.b64decode(encoded, altchars=b'-_', validate=True)
        if len(raw) > 65536 or not hmac.compare_digest(tag, hmac.new(key, raw, hashlib.sha256).hexdigest()):
            raise Refused('invalid_cursor')
        body = json.loads(raw)
        if body['method'] != VERSION:
            raise Refused('cursor_version_mismatch')
        return body
    except (ValueError, KeyError, TypeError) as exc:
        raise Refused('invalid_cursor') from exc


def open_export(engine, *, day, tickers, now, signing_key):
    """Freeze a bounded roster of original source identities, not a trade roster.

    PostgreSQL has built-in md5(text). Synthetic SQLite registers that pure
    function. MD5 here detects accidental changes; SHA256 of each original
    snapshot is also returned when its page is read.
    """
    selected = tuple(sorted(set(tickers)))
    if not 1 <= len(selected) <= MAX_TICKERS or any(not isinstance(t, str) or not t.isalpha() or t != t.upper() for t in selected):
        raise Refused('invalid_tickers')
    start, end = bounds(day, now)
    with session_factory(engine)() as session:
        rows = list(session.execute(select(
            LiveScan.scan_id, LiveScan.finished_at, func.length(LiveScan.snapshot_json), func.md5(LiveScan.snapshot_json),
        ).where(LiveScan.finished_at >= start, LiveScan.finished_at <= end)
          .order_by(LiveScan.finished_at, LiveScan.scan_id).limit(MAX_DAY_SCANS + 1)))
    if len(rows) > MAX_DAY_SCANS:
        raise Refused('source_manifest_limit_exceeded')
    if not rows:
        raise Refused('source_coverage_unknown')
    manifest = [[key, utc(at).isoformat(), size, digest] for key, at, size, digest in rows]
    return _seal({'method': VERSION, 'day': day.isoformat(), 'tickers': selected,
                  'frozen_at': utc(now).isoformat(), 'manifest': manifest,
                  'manifest_sha256': hashlib.sha256(_json(manifest).encode()).hexdigest(),
                  'last_key': None, 'offset': 0}, signing_key)


def export_page(engine, *, cursor, signing_key, max_scans=4,
                max_source_characters=2*1024*1024, max_packet_bytes=2*1024*1024):
    if type(max_scans) is not int or not 1 <= max_scans <= MAX_SCANS:
        raise Refused('invalid_page_limit')
    if type(max_source_characters) is not int or not 1 <= max_source_characters <= 2*1024*1024:
        raise Refused('invalid_source_budget')
    if type(max_packet_bytes) is not int or not 1 <= max_packet_bytes <= 2*1024*1024:
        raise Refused('invalid_packet_budget')
    token = _open(cursor, signing_key)
    manifest = token['manifest']
    offset = token['offset']
    if not 0 <= offset < len(manifest):
        raise Refused('cursor_exhausted')
    chosen, characters = [], 0
    for descriptor in manifest[offset:offset + max_scans]:
        if characters + descriptor[2] > max_source_characters:
            break
        chosen.append(descriptor)
        characters += descriptor[2]
    if not chosen:
        raise Refused('single_scan_exceeds_budget')
    tickers = set(token['tickers'])
    scan_records, requests = [], []
    with session_factory(engine)() as session:
        # Materialize only the selected, already size-bounded source rows.
        rows = {r.scan_id: r for r in session.scalars(select(LiveScan).where(LiveScan.scan_id.in_([d[0] for d in chosen])))}
        for key, at, size, digest in chosen:
            row = rows.get(key)
            if row is None or utc(row.finished_at).isoformat() != at or len(row.snapshot_json) != size or hashlib.md5(row.snapshot_json.encode()).hexdigest() != digest:
                raise Refused('frozen_source_changed')
            try:
                body = json.loads(row.snapshot_json)
                if not isinstance(body, dict):
                    raise ValueError()
            except (ValueError, TypeError) as exc:
                raise Refused('source_payload_invalid') from exc
            checks = body.get('news_observations', {})
            context = body.get('news_research_context', {})
            projection = {'policy_version': body.get('policy_version'),
                          'profile_sha256': body.get('profile_sha256'),
                          'flow_current': body.get('flow_current'),
                          'flow_observations': {t: v for t, v in body.get('flow_observations', {}).items() if t in tickers},
                          'news_observations': {t: v for t, v in checks.items() if t in tickers},
                          'news_research_context': {**context, 'prices': {t: v for t, v in context.get('prices', {}).items() if t in tickers | {'SPY'}}}}
            scan_records.append({'scan_id': key, 'started_at': utc(row.started_at).isoformat(),
                                 'finished_at': at, 'market_mode': row.market_mode, 'status': row.status,
                                 'source_sha256': hashlib.sha256(row.snapshot_json.encode()).hexdigest(),
                                 'projection': projection})
            for ticker in sorted(tickers):
                check = checks.get(ticker)
                if not isinstance(check, dict) or not isinstance(check.get('checked_at'), str):
                    continue
                try:
                    checked = datetime.fromisoformat(check['checked_at'])
                    if checked.tzinfo is None:
                        continue
                except ValueError:
                    continue
                requests.append((len(requests), key, ticker, utc(row.finished_at), utc(checked)))
        top = []
        if requests:
            # One bounded VALUES-equivalent CTE, one ranking query for every
            # (scan,ticker,asof,checked_at) pair. Ties stay visible via rank<=2.
            inputs = union_all(*[select(literal(i).label('request_id'), literal(t).label('ticker'),
                                        literal(at).label('asof'), literal(check).label('check_at'))
                                 for i, _key, t, at, check in requests]).cte('requested_asofs')
            ranked = select(inputs.c.request_id, Packet.key.label('packet_key'),
                            Packet.received_at, func.length(Packet.compressed_payload).label('bytes'),
                            func.row_number().over(partition_by=inputs.c.request_id,
                              order_by=(Packet.received_at.desc(), Packet.key.desc())).label('rank'))\
                .join(Packet, and_(Packet.ticker == inputs.c.ticker, Packet.application_checked_at == inputs.c.check_at,
                                   Packet.received_at <= inputs.c.asof)).subquery()
            top = list(session.execute(select(ranked).where(ranked.c.rank <= 2)
                                       .order_by(ranked.c.request_id, ranked.c.rank)))
        packet_sizes = {r.packet_key: r.bytes for r in top}
        if sum(packet_sizes.values()) > max_packet_bytes:
            raise Refused('packet_bytes_exceeded')
        packet_records = {}
        if packet_sizes:
            # One bounded query, unique packets only. Receipts remain original.
            pairs = session.execute(select(Packet, Receipt).outerjoin(Receipt, Receipt.key == Packet.key)
                                    .where(Packet.key.in_(packet_sizes))).all()
            for packet, receipt in pairs:
                requested, received = utc(packet.requested_at), utc(packet.received_at)
                checked = utc(packet.application_checked_at) if packet.application_checked_at else None
                available = utc(receipt.available_at) if receipt else None
                valid_signature = bool(receipt and receipt.packet_hash == signature(packet.key, packet.ticker, requested, received, packet.payload_hash, packet.succeeded, checked))
                with gzip.GzipFile(fileobj=io.BytesIO(packet.compressed_payload)) as stream:
                    raw = stream.read(8*1024*1024 + 1)
                if len(raw) > 8*1024*1024 or hashlib.sha256(raw).hexdigest() != packet.payload_hash:
                    raise Refused('packet_payload_integrity_failure')
                packet_records[packet.key] = {'packet_key': packet.key, 'ticker': packet.ticker,
                    'payload_sha256': packet.payload_hash, 'requested_at': requested.isoformat(),
                    'received_at': received.isoformat(), 'available_at': available.isoformat() if available else None,
                    'application_checked_at': checked.isoformat() if checked else None,
                    'receipt_signature_valid': valid_signature, 'succeeded': packet.succeeded,
                    'payload_gzip_base64': base64.b64encode(packet.compressed_payload).decode()}
    associations = []
    for i, key, ticker, asof, check in requests:
        matches = [r for r in top if r.request_id == i]
        selected = packet_records.get(matches[0].packet_key) if matches else None
        reason = 'no_physically_captured_news'
        if selected:
            requested = datetime.fromisoformat(selected['requested_at'])
            received = datetime.fromisoformat(selected['received_at'])
            available = datetime.fromisoformat(selected['available_at']) if selected['available_at'] else None
            if len(matches) > 1 and matches[0].received_at == matches[1].received_at:
                reason = 'news_capture_timing_ambiguous'
            elif not selected['receipt_signature_valid']:
                reason = 'physical_receipt_missing_or_invalid'
            elif not requested <= received <= asof or available is None or not received <= available <= asof:
                reason = 'physical_receipt_unavailable'
            elif not selected['succeeded']:
                reason = 'news_retrieval_failed'
            else:
                reason = 'physical_receipt_valid_only_not_news_classification'
        associations.append({'scan_id': key, 'ticker': ticker, 'decision_at': asof.isoformat(),
                             'check_at': check.isoformat(), 'packet_key': selected['packet_key'] if selected else None,
                             'top_two_packet_keys': [r.packet_key for r in matches], 'reason': reason,
                             'news_value': None, 'news_evaluation': 'NOT_PERFORMED'})
    following = offset + len(chosen)
    next_token = {**token, 'offset': following, 'last_key': [chosen[-1][1], chosen[-1][0]]}
    return {'method': VERSION, 'day': token['day'], 'tickers': token['tickers'],
            'frozen_at': token['frozen_at'], 'manifest_sha256': token['manifest_sha256'],
            'manifest_scan_count': len(manifest), 'source_scan_count': len(chosen),
            'source_characters': characters, 'cursor_after': next_token['last_key'],
            'next_cursor': _seal(next_token, signing_key) if following < len(manifest) else None,
            'manifest_exhausted': following == len(manifest),
            'source_coverage': 'UNKNOWN', 'strategy_tests_executed': 0,
            'scans': scan_records, 'packets': list(packet_records.values()), 'associations': associations}
