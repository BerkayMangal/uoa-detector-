UOA physical news source-page prototype

WORK ONLY: undeployed. No provider calls, no strategy evaluation, no runtime or
frozen-storage changes. These source files require the existing UOA repository
and its test dependencies; this ZIP is a review bundle, not a standalone app.

The prototype freezes bounded source identities, limits scan/packet bytes, and
batches top-two as-of packet selection. Its synthetic suite covers 13 cases,
including 72 scan/ticker associations using three SELECT/WITH statements.

Physical provenance wording: available_at is the stored original physical
receipt time with validated packet binding. Existing storage.signature() is
an unkeyed packet metadata checksum; it excludes available_at. Neither the
checksum nor the prototype authenticates that receipt timestamp cryptographically.

Unimplemented deployment requirements include HTTP authorization and cursor
expiry/scope validation, total runtime and SQL statement limits, cumulative
decompression and response limits, and actual PostgreSQL plan/type validation.
Source projections do not reproduce an all-ticker frozen Dataset identity.

Extract these files into a separate work directory. From the UOA repository:
  PYTHONPATH="$PWD:$PWD/src:/path/to/extracted" .venv/bin/python -m pytest -q /path/to/extracted/test_paged_export_prototype.py

The tests create only temporary synthetic SQLite data. profile_export_local.py
also uses synthetic local data, measures unchanged original-export query growth,
and never estimates production PostgreSQL latency. It expects the current
/workspace/uoa-detector- checkout unless its REPO constant is adjusted.

SOURCE_MANIFEST.json records SHA256 and byte count for each unchanged source
file. ZIP entries have safe basename-only paths, fixed timestamps and permissions.
