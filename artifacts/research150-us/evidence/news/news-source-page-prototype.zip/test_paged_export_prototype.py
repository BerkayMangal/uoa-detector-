"""Only synthetic SQLite sources. Production is never contacted."""
from __future__ import annotations

import hashlib
import json
from datetime import timedelta

import pytest
from sqlalchemy import event, select, update
from webapp.board.db import make_engine
from webapp.live_alpha import store
from webapp.news_research import storage

from tests.unit.test_news_adapter import NOW, scan, snapshot
from paged_export_prototype import Refused, export_page, open_export

SECRET = b'synthetic-test-cursor-key-never-used-outside-test'
CHECK = NOW - timedelta(seconds=30)


@pytest.fixture
def source(tmp_path):
    engine = make_engine(f"sqlite:///{tmp_path / 'source.db'}")
    event.listen(engine, 'connect', lambda db, _: db.create_function('md5', 1, lambda text: hashlib.md5(text.encode()).hexdigest()))
    store.ensure_live_tables(engine)
    storage.ensure(engine)
    yield engine
    engine.dispose()


def packet(engine, *, received=None, available=None, tag='one', ticker='NVDA'):
    storage.append(engine, ticker, {'data': [{'id': tag, 'headline': 'Synthetic ' + tag,
        'source': 'TEST', 'tickers': [ticker], 'created_at': (NOW-timedelta(hours=1)).isoformat()}]},
        CHECK, received or NOW-timedelta(seconds=20),
        clock=lambda: available or NOW, application_checked_at=CHECK)


def cursor(engine, count=5, tickers=('NVDA',)):
    for i in range(count):
        body = snapshot()
        body['news_observations'] = {ticker: body['news_observations']['NVDA'] for ticker in tickers}
        scan(engine, f'{i:03}', NOW, body)
    return open_export(engine, day=NOW.date(), tickers=tickers, now=NOW+timedelta(days=2), signing_key=SECRET)


def test_capped_pages_keep_same_timestamp_keys_and_exact_asof_boundary(source):
    packet(source, available=NOW)
    # Published long before decision, but received after it: must not be selected.
    packet(source, received=NOW+timedelta(seconds=1), available=NOW+timedelta(seconds=2), tag='future')
    token = cursor(source)
    found, keys = [], []
    while token:
        page = export_page(source, cursor=token, signing_key=SECRET, max_scans=2)
        assert page['source_scan_count'] <= 2
        assert page['source_coverage'] == 'UNKNOWN'
        found.extend(r['scan_id'] for r in page['scans'])
        keys.extend(r['packet_key'] for r in page['associations'])
        assert all(a['reason'] == 'physical_receipt_valid_only_not_news_classification' for a in page['associations'])
        assert all(p['available_at'] == NOW.isoformat() for p in page['packets'])
        assert all(a['news_value'] is None for a in page['associations'])
        token = page['next_cursor']
    assert found == ['000', '001', '002', '003', '004']
    assert len(set(keys)) == 1


def test_late_physical_receipt_never_backfills_publication(source):
    packet(source, available=NOW+timedelta(microseconds=1))
    page = export_page(source, cursor=cursor(source, 1), signing_key=SECRET)
    assert page['associations'][0]['reason'] == 'physical_receipt_unavailable'
    assert page['associations'][0]['news_value'] is None


def test_tied_latest_packets_preserve_ambiguity(source):
    packet(source, tag='first')
    packet(source, tag='conflicting')
    page = export_page(source, cursor=cursor(source, 1), signing_key=SECRET)
    assert page['associations'][0]['reason'] == 'news_capture_timing_ambiguous'
    assert len(page['associations'][0]['top_two_packet_keys']) == 2


def test_no_sql_n_plus_one_or_writes(source):
    tickers = ('SPY', 'QQQ', 'AAPL', 'NFLX', 'NVDA', 'TSLA', 'MSFT', 'META', 'AMZN')
    for ticker in tickers:
        packet(source, ticker=ticker)
    token = cursor(source, 8, tickers)
    sql = []
    event.listen(source, 'before_cursor_execute', lambda _c, _cur, statement, *_: sql.append(statement))
    page = export_page(source, cursor=token, signing_key=SECRET, max_scans=8)
    assert len(page['associations']) == 72 and len(page['packets']) == 9
    assert len(sql) == 3  # scans, batched top-two ranking, unique packets+receipts
    assert all(s.lstrip().upper().startswith(('SELECT', 'WITH')) for s in sql)
    sql.clear()
    export_page(source, cursor=token, signing_key=SECRET, max_scans=1)
    assert len(sql) == 3


def test_source_byte_cap_refuses_before_snapshot_query(source):
    token = cursor(source, 2)
    sql = []
    event.listen(source, 'before_cursor_execute', lambda _c, _cur, statement, *_: sql.append(statement))
    with pytest.raises(Refused, match='single_scan_exceeds_budget'):
        export_page(source, cursor=token, signing_key=SECRET, max_source_characters=1)
    assert not sql


def test_packet_bytes_checked_before_payload_materialization(source):
    packet(source)
    token = cursor(source, 1)
    sql = []
    event.listen(source, 'before_cursor_execute', lambda _c, _cur, statement, *_: sql.append(statement))
    with pytest.raises(Refused, match='packet_bytes_exceeded'):
        export_page(source, cursor=token, signing_key=SECRET, max_packet_bytes=1)
    assert len(sql) == 2
    assert not any('compressed_payload,' in q for q in sql)


def test_tampered_cursor_never_queries_database(source):
    token = cursor(source, 1)
    sql = []
    event.listen(source, 'before_cursor_execute', lambda _c, _cur, statement, *_: sql.append(statement))
    encoded, tag = token.split('.')
    with pytest.raises(Refused, match='invalid_cursor'):
        export_page(source, cursor=encoded+'.'+('0' if tag[0] != '0' else '1')+tag[1:], signing_key=SECRET)
    assert not sql


def test_same_length_original_revision_is_detected(source):
    token = cursor(source, 1)
    with source.begin() as connection:
        original = connection.scalar(select(store.LiveScan.snapshot_json))
        changed = original.replace('350000', '350001')
        assert len(changed) == len(original) and changed != original
        connection.execute(update(store.LiveScan).values(snapshot_json=changed))
    with pytest.raises(Refused, match='frozen_source_changed'):
        export_page(source, cursor=token, signing_key=SECRET)


def test_backfilled_scan_does_not_rewrite_frozen_manifest_or_claim_full_day(source):
    token = cursor(source, 2)
    scan(source, 'late-backfill', NOW-timedelta(seconds=1), snapshot())
    page = export_page(source, cursor=token, signing_key=SECRET)
    assert [s['scan_id'] for s in page['scans']] == ['000', '001']
    assert page['manifest_scan_count'] == 2 and page['manifest_exhausted']
    assert page['source_coverage'] == 'UNKNOWN'


@pytest.mark.parametrize('cap', [0, 9, True, 1.5])
def test_invalid_page_caps_refuse(source, cap):
    with pytest.raises(Refused, match='invalid_page_limit'):
        export_page(source, cursor='unused', signing_key=SECRET, max_scans=cap)
